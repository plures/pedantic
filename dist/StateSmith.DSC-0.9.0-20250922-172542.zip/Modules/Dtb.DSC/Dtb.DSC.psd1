<#
  .SYNOPSIS
    DSC Helper Module for Dialtone Infrastructure Management.

  .DESCRIPTION
    This module provides user-friendly DSC v3 operations with parameter autocomplete support.
    It automatically handles remote execution without requiring manual setup on remote machines.
    The module is compatible with PowerShell 7 and includes features such as resource mapping,
    installer and resource caching, and platform-specific DSC version management.

  .PARAMETERS
    None.

  .NOTES
    - The module includes helper functions for managing DSC installers and resources.
    - It supports both local and remote DSC operations.
    - Includes Unix-like `head` and `tail` functionality for PowerShell.

  .EXAMPLES
    Import-Module ./Dtb.DSC.psm1
    # Use the module to manage DSC resources and configurations.

    # Example: Get the first 5 lines of a file
    Get-Content file.txt | Get-Head -Count 5

    # Example: Get the last 5 lines of a file
    Get-Content file.txt | Get-Tail -Count 5

    # Example: Initialize installer cache
    Initialize-InstallerCache

    # Example: Get the latest DSC version for Windows
    Get-LatestDscVersion -Platform "Windows"

    # Example: Download a specific DSC resource
    Download-DscResource -ResourceType "Microsoft.Windows/Registry" -Version "1.0.0" -Source "PowerShellGallery"

    # Example: Ensure required DSC resources are available
    Ensure-DscResourcesAvailable -ResourceTypes @("Microsoft.Windows/Registry", "Microsoft.Windows/File") -Force
  #>
@{
  # Script module or binary module file associated with this manifest.
  RootModule           = 'Dtb.DSC.psm1'
    
  # Version number of this module.
  ModuleVersion        = '1.0.0'
    
  # Supported PSEditions
  CompatiblePSEditions = @('Core')
    
  # ID used to uniquely identify this module
  GUID                 = 'a1b2c3d4-e5f6-7890-abcd-ef1234567890'
    
  # Author of this module
  Author               = 'StateSmith Project'
    
  # Company or vendor of this module
  CompanyName          = 'StateSmith'
    
  # Copyright statement for this module
  Copyright            = '(c) StateSmith. All rights reserved.'
    
  # Description of the functionality provided by this module
  Description          = 'DSC Helper Module for StateSmith. Provides user-friendly DSC v3 operations with parameter autocomplete support and automatic remote execution.'
    
  # Minimum version of the PowerShell engine required by this module
  PowerShellVersion    = '7.2'
    
  # Name of the PowerShell host required by this module
  # PowerShellHostName = ''
    
  # Minimum version of the PowerShell host required by this module
  # PowerShellHostVersion = ''
    
  # Minimum version of Microsoft .NET Framework required by this module. This prerequisite is valid for the PowerShell Desktop edition only.
  # DotNetFrameworkVersion = ''
    
  # Minimum version of the common language runtime (CLR) required by this module. This prerequisite is valid for the PowerShell Desktop edition only.
  # CLRVersion = ''
    
  # Processor architecture (None, X86, Amd64) required by this module
  # ProcessorArchitecture = ''
    
  # Modules that must be imported into the global environment prior to importing this module
  # RequiredModules = @()
    
  # Assemblies that must be loaded prior to importing this module
  # RequiredAssemblies = @()
    
  # Script files (.ps1) that are run in the caller's environment prior to importing this module.
  # ScriptsToProcess = @()
    
  # Type files (.ps1xml) to be loaded when importing this module
  # TypesToProcess = @()
    
  # Format files (.ps1xml) to be loaded when importing this module
  # FormatsToProcess = @()
    
  # Modules to import as nested modules of the module specified in RootModule/ModuleToProcess
  # NestedModules = @()
    
  # Functions to export from this module, for best performance, do not use wildcards and do not delete the entry, use an empty array if there are no functions to export.
  FunctionsToExport    = @('Invoke-DscHelper', 'Validate-DscConfiguration', 'Set-DscConfiguration', 'Test-DscConfiguration', 'Export-DscConfiguration', 'Get-DscInstallerCache', 'Update-DscInstallerCache', 'Remove-DscInstallerCache', 'Get-DscInstallerPath', 'Get-DscResourceCache', 'Update-DscResourceCache', 'Remove-DscResourceCache', 'Install-DscResourceOffline', 'Ensure-DscResourcesAvailable', 'Get-Head', 'Get-Tail', 'New-SecureRemoteSession', 'Repair-DscInstallation')

  # Cmdlets to export from this module, for best performance, do not use wildcards and do not delete the entry, use an empty array if there are no cmdlets to export.
  CmdletsToExport      = @()
    
  # Variables to export from this module
  VariablesToExport    = '*'
    
  # Aliases to export from this module, for best performance, do not use wildcards and do not delete the entry, use an empty array if there are no aliases to export.
  AliasesToExport      = @('head', 'tail')
    
  # DSC resources to export from this module
  # DscResourcesToExport = @()
    
  # List of all modules packaged with this module
  # ModuleList = @()
    
  # List of all files packaged with this module
  # FileList = @()
    
  # Private data to pass to the module specified in RootModule/ModuleToProcess. This may also contain a PSData hashtable with additional module metadata used by PowerShell.
  PrivateData          = @{
    PSData = @{
      # Tags applied to this module. These help with module discovery in online galleries.
  Tags         = @('DSC', 'DesiredStateConfiguration', 'Infrastructure', 'Automation', 'StateSmith')
            
      # A URL to the license for this module.
      # LicenseUri = ''
            
      # A URL to the main website for this project.
      # ProjectUri = ''
            
      # A URL to an icon representing this module.
      # IconUri = ''
            
      # ReleaseNotes of this module
  ReleaseNotes = 'Rebranded to StateSmith; helper functions with parameter autocomplete support and automatic remote execution.'
            
      # Prerelease string of this module
      # Prerelease = ''
            
      # Flag to indicate whether the module requires explicit user acceptance for install, update, or save.
      # RequireLicenseAcceptance = $false
            
      # External dependent modules of this module
      # ExternalModuleDependencies = @()
    } # End of PSData hashtable
  } # End of PrivateData hashtable
    
  # HelpInfo URI of this module
  # HelpInfoURI = ''
    
  # Default prefix for commands exported from this module. Override the default prefix using Import-Module -Prefix.
  # DefaultCommandPrefix = ''
} 
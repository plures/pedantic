# DSC Helper Module for Dialtone Infrastructure Management
# Provides user-friendly DSC v3 operations with parameter autocomplete support
# Automatically handles remote execution without manual setup on remote machines
# PowerShell 7 compatible version

# Module configuration
$script:ModuleConfig = @{
  InstallerCachePath  = Join-Path $PSScriptRoot "Installers"
  InstallerCacheFile  = Join-Path $PSScriptRoot "Installers\installer-cache.json"
  ResourceCachePath   = Join-Path $PSScriptRoot "Resources"
  ResourceCacheFile   = Join-Path $PSScriptRoot "Resources\resource-cache.json"
  UpdateCheckInterval = 1  # Days - check daily for updates
  LastUpdateCheckFile = Join-Path $PSScriptRoot "Installers\last-update-check.txt"
  MaxCachedVersions   = 3  # Maximum number of DSC versions to keep cached
  MaxCachedResources  = 50 # Maximum number of resource versions to keep cached
}

# Ensure $PSScriptRoot is set
if (-not $PSScriptRoot) {
  throw "PSScriptRoot is not defined. Please import this script as a module or run it in a context where PSScriptRoot is set."
}

# Resource mapping for classic DSC resources to PowerShell Gallery modules
$script:ResourceMapping = @{
  # Windows resources
  "Microsoft.Windows/Registry"                                = @{
    ModuleName   = "PSDscResources"
    ResourceName = "Registry"
    GalleryName  = "PSDscResources"
    Description  = "Windows Registry configuration resource"
  }
  "Microsoft.Windows/File"                                    = @{
    ModuleName   = "PSDscResources"
    ResourceName = "File"
    GalleryName  = "PSDscResources"
    Description  = "Windows File system resource"
  }
  "Microsoft.Windows/Service"                                 = @{
    ModuleName   = "PSDscResources"
    ResourceName = "Service"
    GalleryName  = "PSDscResources"
    Description  = "Windows Service management resource"
  }
  "Microsoft.Windows/User"                                    = @{
    ModuleName   = "PSDscResources"
    ResourceName = "User"
    GalleryName  = "PSDscResources"
    Description  = "Windows User management resource"
  }
  "Microsoft.Windows/Group"                                   = @{
    ModuleName   = "PSDscResources"
    ResourceName = "Group"
    GalleryName  = "PSDscResources"
    Description  = "Windows Group management resource"
  }
  "Microsoft.Windows/WindowsFeature"                          = @{
    ModuleName   = "PSDscResources"
    ResourceName = "WindowsFeature"
    GalleryName  = "PSDscResources"
    Description  = "Windows Feature installation resource"
  }
  "Microsoft.Windows/WindowsOptionalFeature"                  = @{
    ModuleName   = "PSDscResources"
    ResourceName = "WindowsOptionalFeature"
    GalleryName  = "PSDscResources"
    Description  = "Windows Optional Feature resource"
  }
  "Microsoft.Windows/Process"                                 = @{
    ModuleName   = "PSDscResources"
    ResourceName = "Process"
    GalleryName  = "PSDscResources"
    Description  = "Windows Process management resource"
  }
  "Microsoft.Windows/Log"                                     = @{
    ModuleName   = "PSDscResources"
    ResourceName = "Log"
    GalleryName  = "PSDscResources"
    Description  = "Windows Log resource"
  }
  "Microsoft.Windows/Environment"                             = @{
    ModuleName   = "PSDscResources"
    ResourceName = "Environment"
    GalleryName  = "PSDscResources"
    Description  = "Windows Environment variable resource"
  }
  "Microsoft.Windows/WMI"                                     = @{
    ModuleName   = "xWMI"
    ResourceName = "xWMI"
    GalleryName  = "xWMI"
    Description  = "Windows WMI configuration resource"
  }
  "Microsoft.Windows/WindowsPowerShell"                       = @{
    ModuleName   = "xPowerShellExecutionPolicy"
    ResourceName = "xPowerShellExecutionPolicy"
    GalleryName  = "xPowerShellExecutionPolicy"
    Description  = "Windows PowerShell execution policy resource"
  }
  "Microsoft.Windows/RebootPending"                           = @{
    ModuleName   = "xPendingReboot"
    ResourceName = "xPendingReboot"
    GalleryName  = "xPendingReboot"
    Description  = "Windows Reboot pending detection resource"
  }
  
  # Networking resources
  "Microsoft.Windows/NetAdapterBinding"                       = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetAdapterBinding"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Network adapter binding resource"
  }
  "Microsoft.Windows/DnsServerAddress"                        = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "DnsServerAddress"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows DNS server address resource"
  }
  "Microsoft.Windows/NetAdapterName"                          = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetAdapterName"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Network adapter name resource"
  }
  "Microsoft.Windows/NetAdapterLso"                           = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetAdapterLso"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Network adapter LSO resource"
  }
  "Microsoft.Windows/NetAdapterRss"                           = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetAdapterRss"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Network adapter RSS resource"
  }
  "Microsoft.Windows/NetAdapterAdvancedProperty"              = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetAdapterAdvancedProperty"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Network adapter advanced property resource"
  }
  "Microsoft.Windows/NetAdapterRdma"                          = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetAdapterRdma"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Network adapter RDMA resource"
  }
  "Microsoft.Windows/NetAdapterEncapsulatedPacketTaskOffload" = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetAdapterEncapsulatedPacketTaskOffload"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Network adapter encapsulated packet task offload resource"
  }
  "Microsoft.Windows/NetAdapterHardwareChecksumOffload"       = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetAdapterHardwareChecksumOffload"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Network adapter hardware checksum offload resource"
  }
  "Microsoft.Windows/NetAdapterIPsecOffload"                  = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetAdapterIPsecOffload"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Network adapter IPsec offload resource"
  }
  "Microsoft.Windows/NetAdapterPowerManagement"               = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetAdapterPowerManagement"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Network adapter power management resource"
  }
  "Microsoft.Windows/NetAdapterQos"                           = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetAdapterQos"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Network adapter QoS resource"
  }
  "Microsoft.Windows/NetAdapterRsc"                           = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetAdapterRsc"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Network adapter RSC resource"
  }
  "Microsoft.Windows/NetAdapterSriov"                         = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetAdapterSriov"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Network adapter SR-IOV resource"
  }
  "Microsoft.Windows/NetAdapterVmq"                           = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetAdapterVmq"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Network adapter VMQ resource"
  }
  "Microsoft.Windows/NetBios"                                 = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetBios"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows NetBIOS configuration resource"
  }
  "Microsoft.Windows/NetConnectionProfile"                    = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetConnectionProfile"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Network connection profile resource"
  }
  "Microsoft.Windows/NetIPInterface"                          = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetIPInterface"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Network IP interface resource"
  }
  "Microsoft.Windows/NetOffloadGlobalSetting"                 = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetOffloadGlobalSetting"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Network offload global setting resource"
  }
  "Microsoft.Windows/NetRoute"                                = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetRoute"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Network route resource"
  }
  "Microsoft.Windows/NetTCPSetting"                           = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "NetTCPSetting"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Network TCP setting resource"
  }
  "Microsoft.Windows/ProxySettings"                           = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "ProxySettings"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Proxy settings resource"
  }
  "Microsoft.Windows/WaitForNetAdapter"                       = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "WaitForNetAdapter"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Wait for network adapter resource"
  }
  "Microsoft.Windows/WaitForNetworkTeam"                      = @{
    ModuleName   = "NetworkingDsc"
    ResourceName = "WaitForNetworkTeam"
    GalleryName  = "NetworkingDsc"
    Description  = "Windows Wait for network team resource"
  }
  
  # Computer Management resources
  "Microsoft.Windows/Computer"                                = @{
    ModuleName   = "ComputerManagementDsc"
    ResourceName = "Computer"
    GalleryName  = "ComputerManagementDsc"
    Description  = "Windows Computer management resource"
  }
  "Microsoft.Windows/TimeZone"                                = @{
    ModuleName   = "ComputerManagementDsc"
    ResourceName = "TimeZone"
    GalleryName  = "ComputerManagementDsc"
    Description  = "Windows Time zone configuration resource"
  }
  "Microsoft.Windows/PowerPlan"                               = @{
    ModuleName   = "ComputerManagementDsc"
    ResourceName = "PowerPlan"
    GalleryName  = "ComputerManagementDsc"
    Description  = "Windows Power plan configuration resource"
  }
  "Microsoft.Windows/OfflineDomainJoin"                       = @{
    ModuleName   = "ComputerManagementDsc"
    ResourceName = "OfflineDomainJoin"
    GalleryName  = "ComputerManagementDsc"
    Description  = "Windows Offline domain join resource"
  }
  "Microsoft.Windows/WindowsEventLog"                         = @{
    ModuleName   = "ComputerManagementDsc"
    ResourceName = "WindowsEventLog"
    GalleryName  = "ComputerManagementDsc"
    Description  = "Windows Event log configuration resource"
  }
  "Microsoft.Windows/VirtualMemory"                           = @{
    ModuleName   = "ComputerManagementDsc"
    ResourceName = "VirtualMemory"
    GalleryName  = "ComputerManagementDsc"
    Description  = "Windows Virtual memory configuration resource"
  }
  "Microsoft.Windows/SystemLocale"                            = @{
    ModuleName   = "ComputerManagementDsc"
    ResourceName = "SystemLocale"
    GalleryName  = "ComputerManagementDsc"
    Description  = "Windows System locale configuration resource"
  }
  "Microsoft.Windows/UserAccountControl"                      = @{
    ModuleName   = "ComputerManagementDsc"
    ResourceName = "UserAccountControl"
    GalleryName  = "ComputerManagementDsc"
    Description  = "Windows User account control configuration resource"
  }
  "Microsoft.Windows/IEEnhancedSecurityConfiguration"         = @{
    ModuleName   = "ComputerManagementDsc"
    ResourceName = "IEEnhancedSecurityConfiguration"
    GalleryName  = "ComputerManagementDsc"
    Description  = "Windows IE enhanced security configuration resource"
  }
  "Microsoft.Windows/WindowsCapability"                       = @{
    ModuleName   = "ComputerManagementDsc"
    ResourceName = "WindowsCapability"
    GalleryName  = "ComputerManagementDsc"
    Description  = "Windows Capability installation resource"
  }
  "Microsoft.Windows/WindowsPackageCab"                       = @{
    ModuleName   = "ComputerManagementDsc"
    ResourceName = "WindowsPackageCab"
    GalleryName  = "ComputerManagementDsc"
    Description  = "Windows Package CAB installation resource"
  }
  "Microsoft.Windows/WindowsUpdateAgent"                      = @{
    ModuleName   = "ComputerManagementDsc"
    ResourceName = "WindowsUpdateAgent"
    GalleryName  = "ComputerManagementDsc"
    Description  = "Windows Update agent configuration resource"
  }
  
  # SQL Server resources
  "Microsoft.SqlServer/Database"                              = @{
    ModuleName   = "SqlServerDsc"
    ResourceName = "SqlDatabase"
    GalleryName  = "SqlServerDsc"
    Description  = "SQL Server Database resource"
  }
  "Microsoft.SqlServer/Login"                                 = @{
    ModuleName   = "SqlServerDsc"
    ResourceName = "SqlLogin"
    GalleryName  = "SqlServerDsc"
    Description  = "SQL Server Login resource"
  }
  "Microsoft.SqlServer/Server"                                = @{
    ModuleName   = "SqlServerDsc"
    ResourceName = "SqlServer"
    GalleryName  = "SqlServerDsc"
    Description  = "SQL Server installation resource"
  }
  
  # Active Directory resources
  "Microsoft.ActiveDirectory/User"                            = @{
    ModuleName   = "ActiveDirectoryDsc"
    ResourceName = "ADUser"
    GalleryName  = "ActiveDirectoryDsc"
    Description  = "Active Directory User resource"
  }
  "Microsoft.ActiveDirectory/Group"                           = @{
    ModuleName   = "ActiveDirectoryDsc"
    ResourceName = "ADGroup"
    GalleryName  = "ActiveDirectoryDsc"
    Description  = "Active Directory Group resource"
  }
  "Microsoft.ActiveDirectory/Computer"                        = @{
    ModuleName   = "ActiveDirectoryDsc"
    ResourceName = "ADComputer"
    GalleryName  = "ActiveDirectoryDsc"
    Description  = "Active Directory Computer resource"
  }
  
  # Generic Microsoft resources
  "Microsoft/OSInfo"                                          = @{
    ModuleName   = "PSDscResources"
    ResourceName = "OSInfo"
    GalleryName  = "PSDscResources"
    Description  = "Operating System information resource"
  }
  "Microsoft/DSC/Assertion"                                   = @{
    ModuleName   = "PSDscResources"
    ResourceName = "Assertion"
    GalleryName  = "PSDscResources"
    Description  = "DSC Assertion resource"
  }
  "Microsoft/DSC/Group"                                       = @{
    ModuleName   = "PSDscResources"
    ResourceName = "Group"
    GalleryName  = "PSDscResources"
    Description  = "DSC Group resource"
  }
  "Microsoft/DSC/Include"                                     = @{
    ModuleName   = "PSDscResources"
    ResourceName = "Include"
    GalleryName  = "PSDscResources"
    Description  = "DSC Include resource"
  }
  "Microsoft/DSC/PowerShell"                                  = @{
    ModuleName   = "PSDscResources"
    ResourceName = "PowerShell"
    GalleryName  = "PSDscResources"
    Description  = "DSC PowerShell resource"
  }
  "Microsoft/DSC/Transitional/RunCommandOnSet"                = @{
    ModuleName   = "PSDscResources"
    ResourceName = "RunCommandOnSet"
    GalleryName  = "PSDscResources"
    Description  = "DSC Run command on set resource"
  }
  "Microsoft/DSC/Debug/Echo"                                  = @{
    ModuleName   = "PSDscResources"
    ResourceName = "Echo"
    GalleryName  = "PSDscResources"
    Description  = "DSC Debug echo resource"
  }
}

# PowerShell head and tail commandlets for Unix-like functionality
function Get-Head {
  <#
    .SYNOPSIS
        Gets the first N lines from input (similar to Unix head command).
    .DESCRIPTION
        Returns the first N lines from the input. Default is 10 lines.
    .PARAMETER InputObject
        The input to process.
    .PARAMETER Count
        Number of lines to return (default: 10).
    .EXAMPLE
        Get-Content file.txt | Get-Head -Count 5
    .EXAMPLE
        "line1`nline2`nline3" | Get-Head -Count 2
    #>
  [CmdletBinding()]
  param(
    [Parameter(ValueFromPipeline = $true)]
    [AllowNull()]
    [AllowEmptyString()]
    [string]$InputObject,
    
    [Parameter()]
    [int]$Count = 10
  )
  
  begin {
    $lines = @()
  }
  
  process {
    if ($InputObject) {
      $lines += $InputObject
    }
  }
  
  end {
    $lines | Select-Object -First $Count
  }
}

function Get-Tail {
  <#
    .SYNOPSIS
        Gets the last N lines from input (similar to Unix tail command).
    .DESCRIPTION
        Returns the last N lines from the input. Default is 10 lines.
    .PARAMETER InputObject
        The input to process.
    .PARAMETER Count
        Number of lines to return (default: 10).
    .EXAMPLE
        Get-Content file.txt | Get-Tail -Count 5
    .EXAMPLE
        "line1`nline2`nline3" | Get-Tail -Count 2
    #>
  [CmdletBinding()]
  param(
    [Parameter(ValueFromPipeline = $true)]
    [AllowNull()]
    [AllowEmptyString()]
    [string]$InputObject,
    
    [Parameter()]
    [int]$Count = 10
  )
  
  begin {
    $lines = @()
  }
  
  process {
    if ($InputObject) {
      $lines += $InputObject
    }
  }
  
  end {
    $lines | Select-Object -Last $Count
  }
}

# Create aliases for head and tail
Set-Alias -Name head -Value Get-Head
Set-Alias -Name tail -Value Get-Tail

# Initialize module installer cache
function Initialize-InstallerCache {
  # Validate paths
  if ($null -eq $script:ModuleConfig.InstallerCachePath -or [string]::IsNullOrWhiteSpace($script:ModuleConfig.InstallerCachePath)) {
    throw "InstallerCachePath is null or empty. Check module initialization."
  }
  if ($null -eq $script:ModuleConfig.InstallerCacheFile -or [string]::IsNullOrWhiteSpace($script:ModuleConfig.InstallerCacheFile)) {
    throw "InstallerCacheFile is null or empty. Check module initialization."
  }
  try {
    if (-not (Test-Path $script:ModuleConfig.InstallerCachePath)) {
      New-Item -Path $script:ModuleConfig.InstallerCachePath -ItemType Directory -Force | Out-Null
    }
    if (-not (Test-Path $script:ModuleConfig.InstallerCacheFile)) {
      @{
        LastUpdateCheck   = $null
        AvailableVersions = @{}
        CurrentVersion    = $null
      } | ConvertTo-Json | Set-Content -Path $script:ModuleConfig.InstallerCacheFile
    }
  }
  catch {
    Write-Warning "Failed to initialize installer cache: $($_.Exception.Message)"
    # Don't throw here to prevent call depth overflow
  }
}

# Initialize module resource cache
function Initialize-ResourceCache {
  # Validate paths
  if ($null -eq $script:ModuleConfig.ResourceCachePath -or [string]::IsNullOrWhiteSpace($script:ModuleConfig.ResourceCachePath)) {
    throw "ResourceCachePath is null or empty. Check module initialization."
  }
  if ($null -eq $script:ModuleConfig.ResourceCacheFile -or [string]::IsNullOrWhiteSpace($script:ModuleConfig.ResourceCacheFile)) {
    throw "ResourceCacheFile is null or empty. Check module initialization."
  }
  try {
    if (-not (Test-Path $script:ModuleConfig.ResourceCachePath)) {
      New-Item -Path $script:ModuleConfig.ResourceCachePath -ItemType Directory -Force | Out-Null
    }
    if (-not (Test-Path $script:ModuleConfig.ResourceCacheFile)) {
      @{
        LastUpdateCheck    = $null
        AvailableResources = @{}
        ResourceMetadata   = @{}
        CurrentVersions    = @{}
      } | ConvertTo-Json | Set-Content -Path $script:ModuleConfig.ResourceCacheFile
    }
  }
  catch {
    Write-Warning "Failed to initialize resource cache: $($_.Exception.Message)"
    # Don't throw here to prevent call depth overflow
  }
}

# Get installer cache data
function Get-InstallerCache {
  Initialize-InstallerCache
  
  try {
    $cacheContent = Get-Content -Path $script:ModuleConfig.InstallerCacheFile -Raw -ErrorAction Stop
    $cache = $cacheContent | ConvertFrom-Json -ErrorAction Stop
    
    # Validate cache structure
    if (-not $cache.PSObject.Properties.Name -contains "LastUpdateCheck" -or 
      -not $cache.PSObject.Properties.Name -contains "AvailableVersions" -or 
      -not $cache.PSObject.Properties.Name -contains "CurrentVersion") {
      throw "Invalid cache structure detected"
    }
    
    return $cache
  }
  catch {
    Write-Warning "Failed to read installer cache: $($_.Exception.Message). Reinitializing cache."
    
    # Reinitialize cache with default structure
    @{
      LastUpdateCheck   = $null
      AvailableVersions = @{}
      CurrentVersion    = $null
    } | ConvertTo-Json | Set-Content -Path $script:ModuleConfig.InstallerCacheFile -Force
    
    # Return the default cache structure
    return @{
      LastUpdateCheck   = $null
      AvailableVersions = @{}
      CurrentVersion    = $null
    }
  }
}

# Update installer cache
function Update-InstallerCache {
  param([object]$CacheData)
  $CacheData | ConvertTo-Json | Set-Content -Path $script:ModuleConfig.InstallerCacheFile
}

# Get resource cache data
function Get-ResourceCache {
  Initialize-ResourceCache
  
  try {
    $cacheContent = Get-Content -Path $script:ModuleConfig.ResourceCacheFile -Raw -ErrorAction Stop
    $cache = $cacheContent | ConvertFrom-Json -ErrorAction Stop
    
    # Validate cache structure
    if (-not $cache.PSObject.Properties.Name -contains "LastUpdateCheck" -or 
      -not $cache.PSObject.Properties.Name -contains "AvailableResources" -or 
      -not $cache.PSObject.Properties.Name -contains "ResourceMetadata" -or 
      -not $cache.PSObject.Properties.Name -contains "CurrentVersions") {
      throw "Invalid resource cache structure detected"
    }
    
    return $cache
  }
  catch {
    Write-Warning "Failed to read resource cache: $($_.Exception.Message). Reinitializing cache."
    
    # Reinitialize cache with default structure
    @{
      LastUpdateCheck    = $null
      AvailableResources = @{}
      ResourceMetadata   = @{}
      CurrentVersions    = @{}
    } | ConvertTo-Json | Set-Content -Path $script:ModuleConfig.ResourceCacheFile -Force
    
    # Return the default cache structure
    return @{
      LastUpdateCheck    = $null
      AvailableResources = @{}
      ResourceMetadata   = @{}
      CurrentVersions    = @{}
    }
  }
}

# Update resource cache
function Update-ResourceCache {
  param([object]$CacheData)
  $CacheData | ConvertTo-Json | Set-Content -Path $script:ModuleConfig.ResourceCacheFile
}

# Check if update check is needed
function Test-UpdateCheckNeeded {
  try {
    $cache = Get-InstallerCache
    if (-not $cache.LastUpdateCheck) { return $true }
    
    $lastCheck = [DateTime]::Parse($cache.LastUpdateCheck)
    $daysSinceLastCheck = (Get-Date) - $lastCheck
    return $daysSinceLastCheck.Days -ge $script:ModuleConfig.UpdateCheckInterval
  }
  catch {
    Write-Warning "Failed to check update status: $($_.Exception.Message). Assuming update is needed."
    return $true
  }
}

# Get platform-specific asset information
function Get-PlatformAsset {
  param([string]$Platform, [object[]]$Assets)
  
  switch ($Platform.ToLower()) {
    "windows" {
      # Look for Windows-specific assets (DSC v3 uses x86_64-pc-windows-msvc.zip format)
      $patterns = @(
        "*x86_64-pc-windows-msvc.zip",
        "*x86_64-windows*.zip",
        "*windows*.zip",
        "*win*.zip", 
        "*x64*.zip",
        "*.zip"
      )
    }
    "linux" {
      # Look for Linux-specific assets (DSC v3 uses x86_64-linux.tar.gz format)
      $patterns = @(
        "*x86_64-linux.tar.gz",
        "*x86_64-linux*.tar.gz",
        "*linux*.tar.gz",
        "*linux*.zip",
        "*ubuntu*.tar.gz",
        "*debian*.tar.gz"
      )
    }
    "macos" {
      # Look for macOS-specific assets (DSC v3 uses x86_64-apple-darwin.tar.gz format)
      $patterns = @(
        "*x86_64-apple-darwin.tar.gz",
        "*x86_64-macos*.tar.gz",
        "*macos*.tar.gz",
        "*mac*.tar.gz",
        "*osx*.tar.gz"
      )
    }
    default {
      # Default to Windows for backward compatibility
      $patterns = @("*x86_64-pc-windows-msvc.zip", "*windows*.zip", "*win*.zip", "*.zip")
    }
  }
  
  foreach ($pattern in $patterns) {
    $asset = $Assets | Where-Object { $_.name -like $pattern } | Select-Object -First 1
    if ($asset) {
      return $asset
    }
  }
  
  return $null
}

# Get latest DSC version information
function Get-LatestDscVersion {
  param([string]$Platform = "Windows")
  
  try {
    $releasesUrl = "https://api.github.com/repos/PowerShell/DSC/releases/latest"
    $response = Invoke-RestMethod -Uri $releasesUrl -Method Get
    
    Write-Host "Debug: Found release $($response.tag_name) with $($response.assets.Count) assets" -ForegroundColor Cyan
    
    # Get platform-specific asset
    $platformAsset = Get-PlatformAsset -Platform $Platform -Assets $response.assets
    
    if (-not $platformAsset) {
      Write-Warning "No DSC asset found for platform '$Platform' in latest release. Available assets:"
      foreach ($asset in $response.assets) {
        Write-Warning "  - $($asset.name)"
      }
      return $null
    }
    
    if (-not $platformAsset.browser_download_url) {
      Write-Warning "Download URL not found for DSC asset: $($platformAsset.name)"
      return $null
    }
    
    return @{
      Version     = $response.tag_name.TrimStart('v')
      DownloadUrl = $platformAsset.browser_download_url
      PublishedAt = $response.published_at
      Platform    = $Platform
      AssetName   = $platformAsset.name
    }
  }
  catch {
    Write-Warning "Failed to get latest DSC version information: $($_.Exception.Message)"
    return $null
  }
}

# Download DSC installer
function Download-DscInstaller {
  param([string]$Version, [string]$DownloadUrl, [string]$Platform = "Windows", [string]$AssetName, [switch]$Quiet)
  
  # Determine file extension from asset name
  $fileExtension = if ($AssetName) { [System.IO.Path]::GetExtension($AssetName) } else { ".zip" }
  $installerPath = Join-Path $script:ModuleConfig.InstallerCachePath "DSC-$Version-$Platform$fileExtension"
  
  if (Test-Path $installerPath) {
    if (-not $Quiet) {
      Write-Host "DSC installer version $Version for $Platform already exists locally" -ForegroundColor Green
    }
    return $installerPath
  }
  
  if (-not $Quiet) {
    Write-Host "Downloading DSC installer version $Version for $Platform..." -ForegroundColor Yellow
    Write-Host "Download URL: $DownloadUrl" -ForegroundColor Cyan
    Write-Host "Asset: $AssetName" -ForegroundColor Cyan
  }
  
  try {
    # Validate URL
    if (-not [System.Uri]::IsWellFormedUriString($DownloadUrl, [System.UriKind]::Absolute)) {
      throw "Invalid download URL: $DownloadUrl"
    }
    
    Invoke-WebRequest -Uri $DownloadUrl -OutFile $installerPath -UseBasicParsing
    if (-not $Quiet) {
      Write-Host "DSC installer version $Version for $Platform downloaded successfully" -ForegroundColor Green
    }
    return $installerPath
  }
  catch {
    Write-Error "Failed to download DSC installer version $Version for $Platform`: $($_.Exception.Message)"
    return $null
  }
}

# Update DSC installer cache (internal function)
function Update-DscInstallerCacheInternal {
  param([switch]$Force, [switch]$Quiet, [int]$MaxVersions = $script:ModuleConfig.MaxCachedVersions, [string[]]$Platforms = @("Windows"))
  
  if (-not $Force -and -not (Test-UpdateCheckNeeded)) {
    if (-not $Quiet) {
      Write-Host "DSC installer cache is up to date" -ForegroundColor Green
    }
    return
  }
  
  if (-not $Quiet) {
    Write-Host "Checking for DSC installer updates..." -ForegroundColor Yellow
  }
  
  $cache = Get-InstallerCache
  $cache.LastUpdateCheck = (Get-Date).ToString("o")
  
  # Download for each platform
  foreach ($platform in $Platforms) {
    if (-not $Quiet) {
      Write-Host "Checking for $platform platform..." -ForegroundColor Cyan
    }
    
    $latestVersion = Get-LatestDscVersion -Platform $platform
    if (-not $latestVersion) {
      Write-Warning "Could not retrieve latest DSC version information for $platform"
      continue
    }
    
    if (-not $Quiet) {
      Write-Host "Latest DSC version for $platform found: $($latestVersion.Version)" -ForegroundColor Cyan
    }
    
    # Create platform-specific version key
    $versionKey = "$($latestVersion.Version)-$platform"
    
    # Check if we need to download the latest version for this platform
    if (-not $cache.AvailableVersions.PSObject.Properties.Name -contains $versionKey) {
      $installerPath = Download-DscInstaller -Version $latestVersion.Version -DownloadUrl $latestVersion.DownloadUrl -Platform $platform -AssetName $latestVersion.AssetName -Quiet:$Quiet
      if ($installerPath) {
        $cache.AvailableVersions | Add-Member -MemberType NoteProperty -Name $versionKey -Value @{
          DownloadUrl = $latestVersion.DownloadUrl
          PublishedAt = $latestVersion.PublishedAt
          LocalPath   = $installerPath
          Platform    = $platform
          Version     = $latestVersion.Version
          AssetName   = $latestVersion.AssetName
        } -Force
        
        # Set current version for this platform
        $cache.CurrentVersion = $latestVersion.Version
      }
    }
  }
  
  # Manage version limits
  $cache = Manage-CachedVersions -Cache $cache -MaxVersions $MaxVersions -Quiet:$Quiet
  
  Update-InstallerCache -CacheData $cache
  
  if (-not $Quiet) {
    Write-Host "DSC installer cache updated successfully" -ForegroundColor Green
  }
}

# Manage cached version limits
function Manage-CachedVersions {
  param(
    [object]$Cache,
    [int]$MaxVersions = $script:ModuleConfig.MaxCachedVersions,
    [switch]$Quiet
  )

  # Build a sortable list of versions based on the key prefix before the platform suffix
  $keys = $Cache.AvailableVersions.PSObject.Properties.Name
  $items = foreach ($k in $keys) {
    $v = [Version]"0.0.0"
    if ($k -match '^([^-]+)') {
      try {
        $v = [Version]$matches[1]
      }
      catch {
        $v = [Version]"0.0.0"
      }
    }
    [PSCustomObject]@{ Key = $k; Ver = $v }
  }
  $versions = ($items | Sort-Object Ver -Descending).Key

  if ($versions.Count -le $MaxVersions) {
    return $Cache
  }

  # Keep the most recent versions and remove older ones
  $versionsToKeep = $versions | Select-Object -First $MaxVersions
  $versionsToRemove = $versions | Select-Object -Skip $MaxVersions

  if (-not $Quiet) {
    Write-Host "Managing cached versions: keeping $MaxVersions most recent versions" -ForegroundColor Yellow
  }

  foreach ($version in $versionsToRemove) {
    $installerPath = $Cache.AvailableVersions[$version].LocalPath
    if (Test-Path $installerPath) {
      Remove-Item -Path $installerPath -Force
      if (-not $Quiet) {
        Write-Host "Removed older DSC installer version: $version" -ForegroundColor Yellow
      }
    }
    # Remove from cache
    $Cache.AvailableVersions.PSObject.Properties.Remove($version)
  }

  # Update current version if it was removed
  # Extract version part from the first kept version to update CurrentVersion
  if ($Cache.CurrentVersion -and $versionsToKeep.Count -gt 0) {
    $firstKeptVersion = $versionsToKeep[0]
    if ($firstKeptVersion -match '^([^-]+)') {
      $newCurrentVersion = $matches[1]
      if ($newCurrentVersion -ne $Cache.CurrentVersion) {
        $Cache.CurrentVersion = $newCurrentVersion
        if (-not $Quiet) {
          Write-Host "Updated current version to: $($Cache.CurrentVersion)" -ForegroundColor Yellow
        }
      }
    }
  }

  return $Cache
}

# Get best available DSC installer path
function Get-DscInstallerPath {
  param([string]$PreferredVersion, [string]$TargetPlatform = "Windows", [switch]$Quiet)
  
  # Update cache if needed
  Update-DscInstallerCacheInternal -Quiet:$Quiet -Platforms @($TargetPlatform)
  
  $cache = Get-InstallerCache
  
  if (-not $Quiet) {
    $versions = $cache.AvailableVersions.PSObject.Properties.Name -join ', '
    Write-Host "Available cached versions: $versions" -ForegroundColor Cyan
    Write-Host "Current version: $($cache.CurrentVersion)" -ForegroundColor Cyan
    Write-Host "Target platform: $TargetPlatform" -ForegroundColor Cyan
  }
  
  # Look for platform-specific versions first
  $platformVersions = $cache.AvailableVersions.PSObject.Properties.Name | Where-Object { $_ -like "*-$TargetPlatform" }
  
  # If preferred version is specified, try to use it for the target platform
  if ($PreferredVersion) {
    $preferredKey = "$PreferredVersion-$TargetPlatform"
    if ($cache.AvailableVersions.PSObject.Properties.Name -contains $preferredKey) {
      $installerPath = $cache.AvailableVersions[$preferredKey].LocalPath
      if (Test-Path $installerPath) {
        if (-not $Quiet) {
          Write-Host "Using preferred version for $TargetPlatform - $PreferredVersion" -ForegroundColor Green
        }
        return $installerPath
      }
    }
  }
  
  # Use current version for the target platform
  if ($cache.CurrentVersion) {
    $currentKey = "$($cache.CurrentVersion)-$TargetPlatform"
    if ($cache.AvailableVersions.PSObject.Properties.Name -contains $currentKey) {
      $installerPath = $cache.AvailableVersions[$currentKey].LocalPath
      if (Test-Path $installerPath) {
        if (-not $Quiet) {
          Write-Host "Using current version for $TargetPlatform - $($cache.CurrentVersion)" -ForegroundColor Green
        }
        return $installerPath
      }
    }
  }
  
  # Use any available version for the target platform
  foreach ($version in $platformVersions) {
    $installerPath = $cache.AvailableVersions[$version].LocalPath
    if (Test-Path $installerPath) {
      if (-not $Quiet) {
        Write-Host "Using available version for $TargetPlatform - $version" -ForegroundColor Green
      }
      return $installerPath
    }
  }
  
  # Fallback to any Windows version if target platform not found
  if ($TargetPlatform -ne "Windows") {
    if (-not $Quiet) {
      Write-Host "No $TargetPlatform installer found, checking for Windows fallback..." -ForegroundColor Yellow
    }
    return Get-DscInstallerPath -PreferredVersion $PreferredVersion -TargetPlatform "Windows" -Quiet:$Quiet
  }
  
  if (-not $Quiet) {
    Write-Host "No cached installer found for $TargetPlatform" -ForegroundColor Red
    Write-Host "Available versions in cache: $($cache.AvailableVersions.PSObject.Properties.Name -join ', ')" -ForegroundColor Yellow
    Write-Host "To download installers, run: Update-DscInstallerCache" -ForegroundColor Cyan
    Write-Host "To allow online installation, use -AllowRemoteDownload parameter" -ForegroundColor Cyan
  }
  return $null
}

# Get mapped resource information
function Get-MappedResourceInfo {
  param([string]$ResourceType)
  
  if ($script:ResourceMapping.ContainsKey($ResourceType)) {
    return $script:ResourceMapping[$ResourceType]
  }
  
  # Try partial matching for resources that might not be exactly mapped
  foreach ($key in $script:ResourceMapping.Keys) {
    if ($key -like "*$ResourceType*" -or $ResourceType -like "*$($script:ResourceMapping[$key].ResourceName)*") {
      return $script:ResourceMapping[$key]
    }
  }
  
  return $null
}

# Get available DSC resources from official sources
function Get-DscResourceCatalog {
  param([switch]$Quiet)
  
  try {
    # DSC v3 resources are distributed through multiple channels:
    # 1. Built-in resources (bundled with DSC)
    # 2. PowerShell Gallery (for classic DSC resources via adapters)
    # 3. GitHub releases (for community resources)
    # 4. Microsoft official repositories
    
    $catalog = @{
      BuiltInResources   = @()
      GalleryResources   = @()
      CommunityResources = @()
      OfficialResources  = @()
      MappedResources    = @()
    }
    
    # Get built-in resources from current DSC installation
    if (-not $Quiet) {
      Write-Host "Discovering built-in DSC resources..." -ForegroundColor Cyan
    }
    
    try {
      $builtInResources = & dsc resource list --output-format json 2>&1 | ConvertFrom-Json
      $catalog.BuiltInResources = $builtInResources | ForEach-Object {
        @{
          Type         = $_.type
          Version      = $_.version
          Kind         = $_.kind
          Capabilities = $_.capabilities
          Description  = $_.description
          Directory    = $_.directory
          Path         = $_.path
          Source       = "BuiltIn"
        }
      }
    }
    catch {
      if (-not $Quiet) {
        Write-Warning "Could not discover built-in resources: $($_.Exception.Message)"
      }
    }
    
    # Get PowerShell Gallery resources (classic DSC resources)
    if (-not $Quiet) {
      Write-Host "Discovering PowerShell Gallery DSC resources..." -ForegroundColor Cyan
    }
    
    try {
      # Search for DSC resources in PowerShell Gallery
      $galleryResources = Find-Module -Name "*DSC*" -ErrorAction SilentlyContinue 
      
      # If Find-Module fails or returns no results, try using Save-Module for known DSC modules
      if (-not $galleryResources -or $galleryResources.Count -eq 0) {
        if (-not $Quiet) {
          Write-Host "Find-Module returned no results, trying Save-Module for known DSC modules..." -ForegroundColor Yellow
        }
        
        # List of known DSC modules to try
        $knownDscModules = @(
          "NetworkingDsc",
          "ComputerManagementDsc", 
          "ActiveDirectoryDsc",
          "SqlServerDsc",
          "SharePointDsc",
          "ExchangeDsc",
          "OfficeOnlineServerDsc",
          "FSLogixDsc",
          "PSDscResources",
          "xPSDesiredStateConfiguration"
        )
        
        $galleryResources = @()
        foreach ($moduleName in $knownDscModules) {
          try {
            # Try to get module info using Save-Module approach
            $tempDir = Join-Path $env:TEMP "DscModuleInfo"
            New-Item -Path $tempDir -ItemType Directory -Force | Out-Null
            
            try {
              # Save the module to get its metadata
              Save-Module -Name $moduleName -Path $tempDir -Force -ErrorAction Stop
              $modulePath = Join-Path $tempDir $moduleName
              $moduleManifest = Get-ChildItem -Path $modulePath -Name "*.psd1" | Select-Object -First 1
              
              if ($moduleManifest) {
                $manifestPath = Join-Path $modulePath $moduleManifest
                $manifest = Import-PowerShellDataFile -Path $manifestPath
                
                $galleryResources += [PSCustomObject]@{
                  Name          = $moduleName
                  Version       = $manifest.ModuleVersion
                  Description   = $manifest.Description
                  Author        = $manifest.Author
                  ProjectUri    = $manifest.ProjectUri
                  Tags          = $manifest.Tags
                  PublishedDate = (Get-Date).ToString("o")
                }
                
                if (-not $Quiet) {
                  Write-Host "Successfully discovered $moduleName using Save-Module" -ForegroundColor Green
                }
              }
            }
            finally {
              Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
            }
          }
          catch {
            if (-not $Quiet) {
              Write-Debug "Could not discover $moduleName`: $($_.Exception.Message)"
            }
          }
        }
      }
      
      $catalog.GalleryResources = $galleryResources | ForEach-Object {
        @{
          Name          = $_.Name
          Version       = $_.Version
          Description   = $_.Description
          Author        = $_.Author
          Source        = "PowerShellGallery"
          GalleryUrl    = $_.ProjectUri
          Tags          = $_.Tags
          PublishedDate = $_.PublishedDate
        }
      }
    }
    catch {
      if (-not $Quiet) {
        Write-Warning "Could not discover PowerShell Gallery resources: $($_.Exception.Message)"
      }
    }
    
    # Add mapped resources to catalog
    foreach ($mappedResource in $script:ResourceMapping.GetEnumerator()) {
      $catalog.MappedResources += @{
        OriginalType = $mappedResource.Key
        ModuleName   = $mappedResource.Value.ModuleName
        ResourceName = $mappedResource.Value.ResourceName
        GalleryName  = $mappedResource.Value.GalleryName
        Description  = $mappedResource.Value.Description
        Source       = "Mapped"
      }
    }
    
    # Get community resources from GitHub
    if (-not $Quiet) {
      Write-Host "Discovering community DSC resources..." -ForegroundColor Cyan
    }
    
    try {
      # Search for popular DSC resource repositories
      $communityRepos = @(
        "PowerShell/DscResources",
        "PowerShell/xDscResources", 
        "PowerShell/NetworkingDsc",
        "PowerShell/ComputerManagementDsc",
        "PowerShell/ActiveDirectoryDsc",
        "PowerShell/SqlServerDsc",
        "PowerShell/SharePointDsc",
        "PowerShell/ExchangeDsc",
        "PowerShell/OfficeOnlineServerDsc",
        "PowerShell/FSLogixDsc"
      )
      
      foreach ($repo in $communityRepos) {
        try {
          $releasesUrl = "https://api.github.com/repos/$repo/releases/latest"
          $release = Invoke-RestMethod -Uri $releasesUrl -Method Get -ErrorAction SilentlyContinue
          
          if ($release) {
            $catalog.CommunityResources += @{
              Repository  = $repo
              Version     = $release.tag_name
              PublishedAt = $release.published_at
              DownloadUrl = $release.zipball_url
              Source      = "GitHub"
              Name        = $repo.Split('/')[-1]
            }
          }
        }
        catch {
          # Ignore individual repo failures
          if (-not $Quiet) {
            Write-Debug "Could not get release info for $repo"
          }
        }
      }
    }
    catch {
      if (-not $Quiet) {
        Write-Warning "Could not discover community resources: $($_.Exception.Message)"
      }
    }
    
    # Get official Microsoft DSC resources
    if (-not $Quiet) {
      Write-Host "Discovering official Microsoft DSC resources..." -ForegroundColor Cyan
    }
    
    try {
      $officialRepos = @(
        "PowerShell/DSC",
        "Microsoft/PowerShell-DSC-for-Linux",
        "Microsoft/PowerShell-DSC-for-Linux"
      )
      
      foreach ($repo in $officialRepos) {
        try {
          $releasesUrl = "https://api.github.com/repos/$repo/releases/latest"
          $release = Invoke-RestMethod -Uri $releasesUrl -Method Get -ErrorAction SilentlyContinue
          
          if ($release) {
            $catalog.OfficialResources += @{
              Repository  = $repo
              Version     = $release.tag_name
              PublishedAt = $release.published_at
              DownloadUrl = $release.zipball_url
              Source      = "Microsoft"
              Name        = $repo.Split('/')[-1]
            }
          }
        }
        catch {
          # Ignore individual repo failures
          if (-not $Quiet) {
            Write-Debug "Could not get release info for $repo"
          }
        }
      }
    }
    catch {
      if (-not $Quiet) {
        Write-Warning "Could not discover official resources: $($_.Exception.Message)"
      }
    }
    
    return $catalog
  }
  catch {
    Write-Warning "Failed to get DSC resource catalog: $($_.Exception.Message)"
    return $null
  }
}

# Download DSC resource package
function Download-DscResource {
  param(
    [string]$ResourceType, 
    [string]$Version, 
    [string]$Source, 
    [string]$DownloadUrl, 
    [switch]$Quiet)
  
  # Check if this is a mapped resource
  $mappedInfo = Get-MappedResourceInfo -ResourceType $ResourceType
  if ($mappedInfo) {
    if (-not $Quiet) {
      Write-Host "Resource $ResourceType is mapped to module $($mappedInfo.ModuleName) from PowerShell Gallery" -ForegroundColor Cyan
    }
    $ResourceType = $mappedInfo.ModuleName
    $Source = "PowerShellGallery"
  }
  
  # Create resource-specific directory
  $resourceDir = Join-Path $script:ModuleConfig.ResourceCachePath $ResourceType
  if (-not (Test-Path $resourceDir)) {
    New-Item -Path $resourceDir -ItemType Directory -Force | Out-Null
  }
  
  # Determine file name and path
  $fileName = "$ResourceType-$Version.zip"
  $resourcePath = Join-Path $resourceDir $fileName
  
  if (Test-Path $resourcePath) {
    if (-not $Quiet) {
      Write-Host "DSC resource $ResourceType version $Version already exists locally" -ForegroundColor Green
    }
    return $resourcePath
  }
  
  if (-not $Quiet) {
    Write-Host "Downloading DSC resource $ResourceType version $Version from $Source..." -ForegroundColor Yellow
  }
  
  try {
    # Handle different source types
    switch ($Source.ToLower()) {
      "powershellgallery" {
        # Download from PowerShell Gallery
        $tempDir = Join-Path $env:TEMP "DscResourceDownload"
        New-Item -Path $tempDir -ItemType Directory -Force | Out-Null
        
        try {
          # Use Save-Module to download the module
          Save-Module -Name $ResourceType -Path $tempDir -Force -ErrorAction Stop
          $modulePath = Join-Path $tempDir $ResourceType
          
          # Verify the module was downloaded
          if (-not (Test-Path $modulePath)) {
            throw "Module $ResourceType was not downloaded successfully"
          }
          
          # Create a clean package structure
          $packageDir = Join-Path $env:TEMP "DscResourcePackage"
          New-Item -Path $packageDir -ItemType Directory -Force | Out-Null
          
          try {
            # Copy module files to package directory
            Copy-Item -Path "$modulePath\*" -Destination $packageDir -Recurse -Force
            
            # Create the resource package
            Compress-Archive -Path $packageDir -DestinationPath $resourcePath -Force
          }
          finally {
            Remove-Item -Path $packageDir -Recurse -Force -ErrorAction SilentlyContinue
          }
        }
        finally {
          Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
        }
      }
      "github" {
        # Download from GitHub
        if (-not [System.Uri]::IsWellFormedUriString($DownloadUrl, [System.UriKind]::Absolute)) {
          throw "Invalid download URL: $DownloadUrl"
        }
        
        # Download the ZIP file
        Invoke-WebRequest -Uri $DownloadUrl -OutFile $resourcePath -UseBasicParsing -ErrorAction Stop
        
        # Verify the download
        if (-not (Test-Path $resourcePath) -or (Get-Item $resourcePath).Length -eq 0) {
          throw "Failed to download resource from GitHub or file is empty"
        }
      }
      "microsoft" {
        # Download from Microsoft official sources
        if (-not [System.Uri]::IsWellFormedUriString($DownloadUrl, [System.UriKind]::Absolute)) {
          throw "Invalid download URL: $DownloadUrl"
        }
        
        # Download the ZIP file
        Invoke-WebRequest -Uri $DownloadUrl -OutFile $resourcePath -UseBasicParsing -ErrorAction Stop
        
        # Verify the download
        if (-not (Test-Path $resourcePath) -or (Get-Item $resourcePath).Length -eq 0) {
          throw "Failed to download resource from Microsoft or file is empty"
        }
      }
      "builtin" {
        # Copy from built-in DSC installation
        $dscInstallPath = (Get-Command 'dsc.exe' -ErrorAction SilentlyContinue).Source
        if ($dscInstallPath) {
          $dscDir = Split-Path $dscInstallPath -Parent
          $resourceFiles = Get-ChildItem -Path $dscDir -Recurse -Filter "*$ResourceType*" -ErrorAction SilentlyContinue
          
          if ($resourceFiles) {
            $tempDir = Join-Path $env:TEMP "DscResourceExtract"
            New-Item -Path $tempDir -ItemType Directory -Force | Out-Null
            
            try {
              foreach ($file in $resourceFiles) {
                $relativePath = $file.FullName.Substring($dscDir.Length + 1)
                $targetPath = Join-Path $tempDir $relativePath
                $targetDir = Split-Path $targetPath -Parent
                
                if (-not (Test-Path $targetDir)) {
                  New-Item -Path $targetDir -ItemType Directory -Force | Out-Null
                }
                
                Copy-Item -Path $file.FullName -Destination $targetPath -Force
              }
              
              Compress-Archive -Path $tempDir -DestinationPath $resourcePath -Force
            }
            finally {
              Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
            }
          }
          else {
            throw "Resource $ResourceType not found in DSC installation"
          }
        }
        else {
          throw "DSC installation not found"
        }
      }
      default {
        throw "Unsupported resource source: $Source"
      }
    }
    
    if (-not $Quiet) {
      Write-Host "DSC resource $ResourceType version $Version downloaded successfully" -ForegroundColor Green
    }
    return $resourcePath
  }
  catch {
    Write-Error "Failed to download DSC resource $ResourceType version $Version`: $($_.Exception.Message)"
    return $null
  }
}

# Update DSC resource cache (internal function)
function Update-DscResourceCacheInternal {
  param([switch]$Force, [switch]$Quiet, [int]$MaxResources = $script:ModuleConfig.MaxCachedResources, [string]$SpecificResource)
  
  # If specific resource is requested, try to download it directly
  if ($SpecificResource) {
    if (-not $Quiet) {
      Write-Host "Attempting to download specific resource: $SpecificResource" -ForegroundColor Yellow
    }
    
    $cache = Get-ResourceCache
    $cache.LastUpdateCheck = (Get-Date).ToString("o")
    
    # Check if this is a mapped resource
    $mappedInfo = Get-MappedResourceInfo -ResourceType $SpecificResource
    if ($mappedInfo) {
      try {
        # Try to download from PowerShell Gallery
        $galleryModule = Find-Module -Name $mappedInfo.GalleryName -ErrorAction SilentlyContinue | Select-Object -First 1
        if (-not $galleryModule) {
          # Fallback: try Save-Module directly
          $tempDir = Join-Path $env:TEMP "DscResourceDownload"
          New-Item -Path $tempDir -ItemType Directory -Force | Out-Null
          try {
            Save-Module -Name $mappedInfo.GalleryName -Path $tempDir -Force
            $galleryModule = Get-ChildItem -Path $tempDir -Name $mappedInfo.GalleryName | Select-Object -First 1
            if ($galleryModule) {
              $galleryModule = [PSCustomObject]@{
                Name    = $mappedInfo.GalleryName
                Version = "1.0.0"  # Default version if we can't determine it
              }
            }
          }
          catch {
            if (-not $Quiet) {
              Write-Warning "Failed to download module $($mappedInfo.GalleryName) via Save-Module: $($_.Exception.Message)"
            }
          }
        }
        
        if ($galleryModule) {
          $resourcePath = Download-DscResource -ResourceType $SpecificResource -Version $galleryModule.Version -Source "PowerShellGallery" -Quiet:$Quiet
          if ($resourcePath) {
            $resourceKey = "$SpecificResource-latest"
            $cache.AvailableResources | Add-Member -MemberType NoteProperty -Name $resourceKey -Value @{
              OriginalType = $SpecificResource
              ModuleName   = $mappedInfo.ModuleName
              ResourceName = $mappedInfo.ResourceName
              GalleryName  = $mappedInfo.GalleryName
              Version      = $galleryModule.Version
              Description  = $mappedInfo.Description
              Source       = "Mapped"
              LocalPath    = $resourcePath
              DownloadedAt = (Get-Date).ToString("o")
            } -Force
            
            Update-ResourceCache -CacheData $cache
            
            if (-not $Quiet) {
              Write-Host "Successfully downloaded specific resource: $SpecificResource" -ForegroundColor Green
            }
            return $true
          }
        }
      }
      catch {
        if (-not $Quiet) {
          Write-Warning "Failed to download specific resource $SpecificResource`: $($_.Exception.Message)"
        }
      }
    }
    else {
      # Try to find in PowerShell Gallery directly
      try {
        $galleryModule = Find-Module -Name $SpecificResource -ErrorAction SilentlyContinue | Select-Object -First 1
        if (-not $galleryModule) {
          # Try with common DSC module naming patterns
          $possibleNames = @("$SpecificResource", "Dsc$SpecificResource", "$SpecificResource`Dsc")
          foreach ($name in $possibleNames) {
            $galleryModule = Find-Module -Name $name -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($galleryModule) { break }
          }
        }
        
        if ($galleryModule) {
          $resourcePath = Download-DscResource -ResourceType $SpecificResource -Version $galleryModule.Version -Source "PowerShellGallery" -Quiet:$Quiet
          if ($resourcePath) {
            $resourceKey = "$SpecificResource-$($galleryModule.Version)"
            $cache.AvailableResources | Add-Member -MemberType NoteProperty -Name $resourceKey -Value @{
              Name          = $SpecificResource
              Version       = $galleryModule.Version
              Description   = $galleryModule.Description
              Author        = $galleryModule.Author
              Source        = "PowerShellGallery"
              GalleryUrl    = $galleryModule.ProjectUri
              Tags          = $galleryModule.Tags
              PublishedDate = $galleryModule.PublishedDate
              LocalPath     = $resourcePath
              DownloadedAt  = (Get-Date).ToString("o")
            } -Force
            
            Update-ResourceCache -CacheData $cache
            
            if (-not $Quiet) {
              Write-Host "Successfully downloaded specific resource: $SpecificResource" -ForegroundColor Green
            }
            return $true
          }
        }
      }
      catch {
        if (-not $Quiet) {
          Write-Warning "Failed to download specific resource $SpecificResource`: $($_.Exception.Message)"
        }
      }
    }
    
    if (-not $Quiet) {
      Write-Warning "Could not download specific resource: $SpecificResource"
    }
    return $false
  }
  
  if (-not $Force -and -not (Test-UpdateCheckNeeded)) {
    if (-not $Quiet) {
      Write-Host "DSC resource cache is up to date" -ForegroundColor Green
    }
    return
  }
  
  if (-not $Quiet) {
    Write-Host "Checking for DSC resource updates..." -ForegroundColor Yellow
  }
  
  $cache = Get-ResourceCache
  $cache.LastUpdateCheck = (Get-Date).ToString("o")
  
  # Get resource catalog
  $catalog = Get-DscResourceCatalog -Quiet:$Quiet
  if (-not $catalog) {
    Write-Warning "Could not retrieve DSC resource catalog"
    return
  }
  
  $downloadCount = 0
  $errorCount = 0
  
  # Process built-in resources
  if (-not $Quiet) {
    Write-Host "Processing built-in DSC resources..." -ForegroundColor Cyan
  }
  
  foreach ($resource in $catalog.BuiltInResources) {
    $resourceKey = "$($resource.Type)-$($resource.Version)"
    
    if (-not $cache.AvailableResources.PSObject.Properties.Name -contains $resourceKey) {
      try {
        $resourcePath = Download-DscResource -ResourceType $resource.Type -Version $resource.Version -Source $resource.Source -Quiet:$Quiet
        if ($resourcePath) {
          $cache.AvailableResources | Add-Member -MemberType NoteProperty -Name $resourceKey -Value @{
            Type         = $resource.Type
            Version      = $resource.Version
            Kind         = $resource.Kind
            Capabilities = $resource.Capabilities
            Description  = $resource.Description
            Directory    = $resource.Directory
            Path         = $resource.Path
            Source       = $resource.Source
            LocalPath    = $resourcePath
            DownloadedAt = (Get-Date).ToString("o")
          } -Force
          
          # Store metadata
          $cache.ResourceMetadata | Add-Member -MemberType NoteProperty -Name $resource.Type -Value @{
            LatestVersion = $resource.Version
            LastUpdated   = (Get-Date).ToString("o")
            Source        = $resource.Source
          } -Force
          
          $downloadCount++
        }
      }
      catch {
        $errorCount++
        if (-not $Quiet) {
          Write-Warning "Failed to download built-in resource $($resource.Type): $($_.Exception.Message)"
        }
      }
    }
  }
  
  # Process mapped resources (classic DSC resources that need to be downloaded from PowerShell Gallery)
  if (-not $Quiet) {
    Write-Host "Processing mapped DSC resources..." -ForegroundColor Cyan
  }
  
  foreach ($mappedResource in $catalog.MappedResources) {
    $resourceKey = "$($mappedResource.OriginalType)-latest"
    
    if (-not $cache.AvailableResources.PSObject.Properties.Name -contains $resourceKey) {
      try {
        # Get the latest version from PowerShell Gallery
        $galleryModule = Find-Module -Name $mappedResource.GalleryName -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($galleryModule) {
          $resourcePath = Download-DscResource -ResourceType $mappedResource.OriginalType -Version $galleryModule.Version -Source "PowerShellGallery" -Quiet:$Quiet
          if ($resourcePath) {
            $cache.AvailableResources | Add-Member -MemberType NoteProperty -Name $resourceKey -Value @{
              OriginalType = $mappedResource.OriginalType
              ModuleName   = $mappedResource.ModuleName
              ResourceName = $mappedResource.ResourceName
              GalleryName  = $mappedResource.GalleryName
              Version      = $galleryModule.Version
              Description  = $mappedResource.Description
              Source       = "Mapped"
              LocalPath    = $resourcePath
              DownloadedAt = (Get-Date).ToString("o")
            } -Force
            
            # Store metadata
            $cache.ResourceMetadata | Add-Member -MemberType NoteProperty -Name $mappedResource.OriginalType -Value @{
              LatestVersion = $galleryModule.Version
              LastUpdated   = (Get-Date).ToString("o")
              Source        = "Mapped"
              ModuleName    = $mappedResource.ModuleName
            } -Force
            
            $downloadCount++
          }
        }
      }
      catch {
        $errorCount++
        if (-not $Quiet) {
          Write-Warning "Failed to download mapped resource $($mappedResource.OriginalType): $($_.Exception.Message)"
        }
      }
    }
  }
  
  # Process PowerShell Gallery resources
  if (-not $Quiet) {
    Write-Host "Processing PowerShell Gallery DSC resources..." -ForegroundColor Cyan
  }
  
  foreach ($resource in $catalog.GalleryResources) {
    $resourceKey = "$($resource.Name)-$($resource.Version)"
    
    if (-not $cache.AvailableResources.PSObject.Properties.Name -contains $resourceKey) {
      try {
        $resourcePath = Download-DscResource -ResourceType $resource.Name -Version $resource.Version -Source $resource.Source -Quiet:$Quiet
        if ($resourcePath) {
          $cache.AvailableResources | Add-Member -MemberType NoteProperty -Name $resourceKey -Value @{
            Name          = $resource.Name
            Version       = $resource.Version
            Description   = $resource.Description
            Author        = $resource.Author
            Source        = $resource.Source
            GalleryUrl    = $resource.GalleryUrl
            Tags          = $resource.Tags
            PublishedDate = $resource.PublishedDate
            LocalPath     = $resourcePath
            DownloadedAt  = (Get-Date).ToString("o")
          } -Force
          
          # Store metadata
          $cache.ResourceMetadata | Add-Member -MemberType NoteProperty -Name $resource.Name -Value @{
            LatestVersion = $resource.Version
            LastUpdated   = (Get-Date).ToString("o")
            Source        = $resource.Source
          } -Force
          
          $downloadCount++
        }
      }
      catch {
        $errorCount++
        if (-not $Quiet) {
          Write-Warning "Failed to download Gallery resource $($resource.Name): $($_.Exception.Message)"
        }
      }
    }
  }
  
  # Process community resources from GitHub
  if (-not $Quiet) {
    Write-Host "Processing community DSC resources..." -ForegroundColor Cyan
  }
  
  foreach ($resource in $catalog.CommunityResources) {
    $resourceKey = "$($resource.Name)-$($resource.Version)"
    
    if (-not $cache.AvailableResources.PSObject.Properties.Name -contains $resourceKey) {
      try {
        $resourcePath = Download-DscResource -ResourceType $resource.Name -Version $resource.Version -Source $resource.Source -DownloadUrl $resource.DownloadUrl -Quiet:$Quiet
        if ($resourcePath) {
          $cache.AvailableResources | Add-Member -MemberType NoteProperty -Name $resourceKey -Value @{
            Name         = $resource.Name
            Version      = $resource.Version
            Repository   = $resource.Repository
            PublishedAt  = $resource.PublishedAt
            Source       = $resource.Source
            LocalPath    = $resourcePath
            DownloadedAt = (Get-Date).ToString("o")
          } -Force
          
          # Store metadata
          $cache.ResourceMetadata | Add-Member -MemberType NoteProperty -Name $resource.Name -Value @{
            LatestVersion = $resource.Version
            LastUpdated   = (Get-Date).ToString("o")
            Source        = $resource.Source
          } -Force
          
          $downloadCount++
        }
      }
      catch {
        $errorCount++
        if (-not $Quiet) {
          Write-Warning "Failed to download community resource $($resource.Name): $($_.Exception.Message)"
        }
      }
    }
  }
  
  # Process official Microsoft resources
  if (-not $Quiet) {
    Write-Host "Processing official Microsoft DSC resources..." -ForegroundColor Cyan
  }
  
  foreach ($resource in $catalog.OfficialResources) {
    $resourceKey = "$($resource.Name)-$($resource.Version)"
    
    if (-not $cache.AvailableResources.PSObject.Properties.Name -contains $resourceKey) {
      try {
        $resourcePath = Download-DscResource -ResourceType $resource.Name -Version $resource.Version -Source $resource.Source -DownloadUrl $resource.DownloadUrl -Quiet:$Quiet
        if ($resourcePath) {
          $cache.AvailableResources | Add-Member -MemberType NoteProperty -Name $resourceKey -Value @{
            Name         = $resource.Name
            Version      = $resource.Version
            Repository   = $resource.Repository
            PublishedAt  = $resource.PublishedAt
            Source       = $resource.Source
            LocalPath    = $resourcePath
            DownloadedAt = (Get-Date).ToString("o")
          } -Force
          
          # Store metadata
          $cache.ResourceMetadata | Add-Member -MemberType NoteProperty -Name $resource.Name -Value @{
            LatestVersion = $resource.Version
            LastUpdated   = (Get-Date).ToString("o")
            Source        = $resource.Source
          } -Force
          
          $downloadCount++
        }
      }
      catch {
        $errorCount++
        if (-not $Quiet) {
          Write-Warning "Failed to download official resource $($resource.Name): $($_.Exception.Message)"
        }
      }
    }
  }
  
  # Manage resource limits
  $cache = Manage-CachedResources -Cache $cache -MaxResources $MaxResources -Quiet:$Quiet
  
  Update-ResourceCache -CacheData $cache
  
  if (-not $Quiet) {
    Write-Host "DSC resource cache updated successfully" -ForegroundColor Green
    Write-Host "Downloaded $downloadCount new resources, $errorCount errors encountered" -ForegroundColor Cyan
  }
}

# Manage cached resource limits
function Manage-CachedResources {
  param([object]$Cache, [int]$MaxResources = $script:ModuleConfig.MaxCachedResources, [switch]$Quiet)
  
  $resources = $Cache.AvailableResources.PSObject.Properties.Name | Sort-Object -Descending
  
  if ($resources.Count -le $MaxResources) {
    return $Cache
  }
  
  # Keep the most recent resources and remove older ones
  $resourcesToKeep = $resources | Select-Object -First $MaxResources
  $resourcesToRemove = $resources | Select-Object -Skip $MaxResources
  
  if (-not $Quiet) {
    Write-Host "Managing cached resources: keeping $MaxResources most recent resources" -ForegroundColor Yellow
  }
  
  foreach ($resource in $resourcesToRemove) {
    $resourcePath = $Cache.AvailableResources[$resource].LocalPath
    if (Test-Path $resourcePath) {
      Remove-Item -Path $resourcePath -Force
      if (-not $Quiet) {
        Write-Host "Removed older DSC resource: $resource" -ForegroundColor Yellow
      }
    }
    
    # Remove from cache
    $Cache.AvailableResources.PSObject.Properties.Remove($resource)
  }
  
  return $Cache
}

# Get best available DSC resource path
function Get-DscResourcePath {
  param([string]$ResourceType, [string]$PreferredVersion, [switch]$Quiet)
  
  # Update cache if needed
  Update-DscResourceCacheInternal -Quiet:$Quiet
  
  # Load cache directly to avoid function scope issues
  Initialize-ResourceCache
  $cacheContent = Get-Content -Path $script:ModuleConfig.ResourceCacheFile -Raw
  $cache = $cacheContent | ConvertFrom-Json
  
  if (-not $Quiet) {
    $resources = $cache.AvailableResources.PSObject.Properties.Name -join ', '
    Write-Host "Available cached resources: $resources" -ForegroundColor Cyan
    Write-Host "Target resource: $ResourceType" -ForegroundColor Cyan
  }
  
  # Check if this is a mapped resource
  $mappedInfo = Get-MappedResourceInfo -ResourceType $ResourceType
  if ($mappedInfo) {
    if (-not $Quiet) {
      Write-Host "Resource $ResourceType is mapped to module $($mappedInfo.ModuleName)" -ForegroundColor Cyan
    }
    
    # Look for mapped resource in cache
    $mappedKey = "$ResourceType-latest"
    if ($cache.AvailableResources.PSObject.Properties.Name -contains $mappedKey) {
      $resourceObj = $cache.AvailableResources.PSObject.Properties[$mappedKey].Value
      $resourcePath = $resourceObj.LocalPath
      if (Test-Path $resourcePath) {
        if (-not $Quiet) {
          Write-Host "Using mapped resource for $ResourceType" -ForegroundColor Green
        }
        return $resourcePath
      }
    }
    
    # If not found, try to download it now
    if (-not $Quiet) {
      Write-Host "Mapped resource not found in cache, attempting to download..." -ForegroundColor Yellow
    }
    
    try {
      $galleryModule = Find-Module -Name $mappedInfo.GalleryName -ErrorAction SilentlyContinue | Select-Object -First 1
      if ($galleryModule) {
        $resourcePath = Download-DscResource -ResourceType $ResourceType -Version $galleryModule.Version -Source "PowerShellGallery" -Quiet:$Quiet
        if ($resourcePath) {
          # Add to cache
          $cache = Get-ResourceCache
          $cache.AvailableResources | Add-Member -MemberType NoteProperty -Name $mappedKey -Value @{
            OriginalType = $ResourceType
            ModuleName   = $mappedInfo.ModuleName
            ResourceName = $mappedInfo.ResourceName
            GalleryName  = $mappedInfo.GalleryName
            Version      = $galleryModule.Version
            Description  = $mappedInfo.Description
            Source       = "Mapped"
            LocalPath    = $resourcePath
            DownloadedAt = (Get-Date).ToString("o")
          } -Force
          
          Update-ResourceCache -CacheData $cache
          
          if (-not $Quiet) {
            Write-Host "Successfully downloaded and cached mapped resource for $ResourceType" -ForegroundColor Green
          }
          return $resourcePath
        }
      }
    }
    catch {
      if (-not $Quiet) {
        Write-Warning "Failed to download mapped resource $ResourceType`: $($_.Exception.Message)"
      }
    }
  }
  
  # Look for exact resource type match (support partial matches and return latest version)
  $matchingResources = $cache.AvailableResources.PSObject.Properties.Name | Where-Object { $_ -like "$ResourceType-*" -or $_ -eq $ResourceType -or $_ -like "$ResourceType*" }
  
  # If preferred version is specified, try to use it
  if ($PreferredVersion) {
    $preferredKey = "$ResourceType-$PreferredVersion"
    if ($cache.AvailableResources.PSObject.Properties.Name -contains $preferredKey) {
      $resourceObj = $cache.AvailableResources.PSObject.Properties[$preferredKey].Value
      $resourcePath = $resourceObj.LocalPath
      if (Test-Path $resourcePath) {
        if (-not $Quiet) {
          Write-Host "Using preferred version for $ResourceType - $PreferredVersion" -ForegroundColor Green
        }
        return $resourcePath
      }
    }
  }
  
  # Use latest version (sort by version if possible)
  if ($matchingResources.Count -gt 0) {
    # Try to sort by version number if possible
    $latestResource = $matchingResources | Sort-Object { 
      if ($_ -match "-(\d+\.[\d\.]+)$") { [version]$matches[1] } else { [version]"0.0.0.0" } 
    } -Descending | Select-Object -First 1
    
    if (-not $Quiet) {
      Write-Host "Debug: Latest resource key: $latestResource" -ForegroundColor Cyan
      Write-Host "Debug: Type of AvailableResources: $($cache.AvailableResources.GetType().FullName)" -ForegroundColor Cyan
      Write-Host "Debug: Keys: $($cache.AvailableResources.PSObject.Properties.Name -join ', ')" -ForegroundColor Cyan
    }
    
    $resourceObj = $cache.AvailableResources.PSObject.Properties[$latestResource].Value
    $resourcePath = $resourceObj.LocalPath
    
    if (-not $Quiet) {
      Write-Host "Debug: Resource path: $resourcePath" -ForegroundColor Cyan
    }
    
    if ($resourcePath -and (Test-Path $resourcePath)) {
      if (-not $Quiet) {
        Write-Host "Using available version for $ResourceType - $latestResource" -ForegroundColor Green
      }
      return $resourcePath
    }
    else {
      if (-not $Quiet) {
        Write-Host "Debug: Resource path is null or file doesn't exist" -ForegroundColor Yellow
      }
    }
  }
  
  if (-not $Quiet) {
    Write-Host "No cached resource found for $ResourceType" -ForegroundColor Red
  }
  return $null
}

# Ensure required DSC resources are available in cache
function Test-DscResourceAvailability {
  [CmdletBinding()]
  param(
    [string[]]$ResourceTypes,
    [switch]$Quiet,
    [switch]$Force
  )
  
  if (-not $ResourceTypes -or $ResourceTypes.Count -eq 0) {
    return @{ Success = $true; MissingResources = @() }
  }
  
  if (-not $Quiet) {
    Write-Host "Ensuring required DSC resources are available in cache..." -ForegroundColor Yellow
  }
  
  $missingResources = @()
  $availableResources = @()
  
  foreach ($resourceType in $ResourceTypes) {
    $resourcePath = Get-DscResourcePath -ResourceType $resourceType -Quiet:$Quiet
    if ($resourcePath) {
      $availableResources += $resourceType
      if (-not $Quiet) {
        Write-Host "✓ Resource available: $resourceType" -ForegroundColor Green
      }
    }
    else {
      $missingResources += $resourceType
      if (-not $Quiet) {
        Write-Host "✗ Resource missing: $resourceType" -ForegroundColor Red
      }
    }
  }
  
  # If we have missing resources and Force is specified, try to update the cache
  if ($missingResources.Count -gt 0 -and $Force) {
    if (-not $Quiet) {
      Write-Host "Force flag specified - attempting to download missing resources..." -ForegroundColor Yellow
    }
    
    Update-DscResourceCacheInternal -Force -Quiet:$Quiet
    
    # Check again after cache update
    $stillMissing = @()
    foreach ($resourceType in $missingResources) {
      $resourcePath = Get-DscResourcePath -ResourceType $resourceType -Quiet:$Quiet
      if ($resourcePath) {
        $availableResources += $resourceType
        if (-not $Quiet) {
          Write-Host "✓ Resource now available: $resourceType" -ForegroundColor Green
        }
      }
      else {
        $stillMissing += $resourceType
        if (-not $Quiet) {
          Write-Host "✗ Resource still missing: $resourceType" -ForegroundColor Red
        }
      }
    }
    $missingResources = $stillMissing
  }
  
  return @{
    Success            = $missingResources.Count -eq 0
    AvailableResources = $availableResources
    MissingResources   = $missingResources
    TotalRequested     = $ResourceTypes.Count
    TotalAvailable     = $availableResources.Count
    TotalMissing       = $missingResources.Count
  }
}

# Back-compat shim. Prefer Test-DscResourceAvailability (approved verb).
function Ensure-DscResourcesAvailable {
  [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseApprovedVerbs','', Justification='Backward compatibility; use Test-DscResourceAvailability instead.')]
  [CmdletBinding()]
  param(
    [string[]]$ResourceTypes,
    [switch]$Quiet,
    [switch]$Force
  )
  Write-Warning "Ensure-DscResourcesAvailable is deprecated. Use Test-DscResourceAvailability instead."
  Test-DscResourceAvailability -ResourceTypes $ResourceTypes -Quiet:$Quiet -Force:$Force
}

# Validate DSC executable availability
function Test-DscExecutable {
  if (-not (Get-Command 'dsc.exe' -ErrorAction SilentlyContinue)) {
    throw "DSC executable (dsc.exe) not found in PATH. Please ensure DSC v3 is installed and available."
  }
}

# Validate file paths
function Test-DscPaths {
  param([string]$DscPath, [string]$ParametersPath)
  
  if (-not (Test-Path -Path $DscPath -PathType Leaf)) {
    throw "DSC configuration file not found: $DscPath"
  }
      
  if ($ParametersPath -and -not (Test-Path -Path $ParametersPath -PathType Leaf)) {
    throw "Parameters file not found: $ParametersPath"
  }
}

# Build DSC command arguments
function Build-DscArguments {
  param([string]$Operation, [string]$DscPath, [string]$ParametersPath, [switch]$WhatIf)
  
  $dscArgs = @('config', $Operation.ToLower())
      
  # Add file parameter
  $dscArgs += '--file'
  $dscArgs += $DscPath
      
  # Add parameters file if specified
  if ($ParametersPath) {
    $dscArgs += '--parametersFile'
    $dscArgs += $ParametersPath
  }
      
  # Add WhatIf flag for Set operation
  if ($WhatIf -and $Operation -eq 'Set') {
    $dscArgs += '--whatif'
  }
      
  # Add output format for structured results
  $dscArgs += '--output-format'
  $dscArgs += 'json'
      
  return $dscArgs
}

# Execute DSC command
function Invoke-DscCommand {
  param([string[]]$Arguments, [string]$TargetComputer, [switch]$Quiet)
      
  $cmdLine = "dsc $($Arguments -join ' ')"
      
  if (-not $Quiet) {
    Write-Host "Executing: $cmdLine" -ForegroundColor Cyan
  }
      
  try {
    $output = & dsc @Arguments 2>&1
    $exitCode = $LASTEXITCODE
            
    if (-not $Quiet) {
      Write-Host "Exit Code: $exitCode" -ForegroundColor $(if ($exitCode -eq 0) { 'Green' } else { 'Red' })
    }
            
    return @{
      ExitCode    = $exitCode
      Output      = $output
      CommandLine = $cmdLine
    }
  }
  catch {
    throw "Failed to execute DSC command: $($_.Exception.Message)"
  }
}

# Convert DSC output (string or string[]) to a JSON object robustly
function Convert-FromDscJson {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$true)]
    $Output
  )

  # Normalize to a single string
  $text = if ($Output -is [System.Array]) { ($Output -join "`n") } else { [string]$Output }
  if ([string]::IsNullOrWhiteSpace($text)) {
    throw "DSC returned no output to parse as JSON."
  }

  # Remove BOM and leading whitespace
  $text = $text.TrimStart([char]0xFEFF).Trim()

  # First attempt direct parse
  try { return ($text | ConvertFrom-Json -ErrorAction Stop) } catch { }

  # Attempt to extract JSON payload from mixed output
  $firstBrace = $text.IndexOf('{')
  $firstBracket = $text.IndexOf('[')
  $startIdx = -1
  if ($firstBrace -ge 0 -and $firstBracket -ge 0) {
    $startIdx = [Math]::Min($firstBrace, $firstBracket)
  }
  elseif ($firstBrace -ge 0) { $startIdx = $firstBrace }
  elseif ($firstBracket -ge 0) { $startIdx = $firstBracket }

  if ($startIdx -lt 0) {
    throw "Failed to locate JSON in DSC output. Raw output:`n$text"
  }

  $candidate = $text.Substring($startIdx)
  # Trim trailing non-JSON by finding the last likely closing char
  $lastBrace = $candidate.LastIndexOf('}')
  $lastBracket = $candidate.LastIndexOf(']')
  $endIdx = -1
  if ($lastBrace -ge 0 -and $lastBracket -ge 0) {
    $endIdx = [Math]::Max($lastBrace, $lastBracket)
  }
  elseif ($lastBrace -ge 0) { $endIdx = $lastBrace }
  elseif ($lastBracket -ge 0) { $endIdx = $lastBracket }

  if ($endIdx -ge 0) {
    $candidate = $candidate.Substring(0, $endIdx + 1)
  }

  try { return ($candidate | ConvertFrom-Json -ErrorAction Stop) }
  catch {
    throw "Conversion from JSON failed. Raw output excerpt:`n$candidate"
  }
}

# Install DSC v3 on remote machine
function Install-RemoteDsc {
  param([System.Management.Automation.Runspaces.PSSession]$Session, [string]$TargetComputer, [switch]$Quiet, [string]$LocalInstallerPath, [switch]$AllowOnlineInstallation)
  
  if (-not $Quiet) {
    Write-Host "Installing DSC v3 on $TargetComputer..." -ForegroundColor Yellow
  }
  
  try {
    $installResult = Invoke-Command -Session $Session -ScriptBlock {
      param($LocalInstallerPath, $AllowOnlineInstallation)
      
      # Priority 1: Use local installer if provided
      if ($LocalInstallerPath) {
        try {
          Write-Host "Attempting to install DSC v3 using local installer..." -ForegroundColor Cyan
          
          $fileExtension = [System.IO.Path]::GetExtension($LocalInstallerPath).ToLower()
          
          if ($fileExtension -eq ".zip") {
            # Extract and install from ZIP (DSC v3 Windows distribution)
            Write-Host "Extracting and installing DSC v3 from ZIP file..." -ForegroundColor Cyan
            $extractPath = Join-Path $env:TEMP "DscExtract"
            Expand-Archive -Path $LocalInstallerPath -DestinationPath $extractPath -Force
            
            # DSC v3 is a standalone executable - look for dsc.exe
            $dscExe = Get-ChildItem -Path $extractPath -Recurse -Name "dsc.exe" | Select-Object -First 1
            if ($dscExe) {
              $dscPath = Join-Path $extractPath $dscExe
              $dscDir = Split-Path $dscPath -Parent
              
              # Install to Program Files
              $installDir = "C:\Program Files\Microsoft DSC"
              New-Item -Path $installDir -ItemType Directory -Force | Out-Null
              
              # Copy ALL files from the extracted directory to maintain proper structure
              Write-Host "Copying all DSC files to installation directory..." -ForegroundColor Cyan
              Copy-Item -Path "$dscDir\*" -Destination $installDir -Recurse -Force
              
              # Add to PATH if not already there
              $currentPath = [Environment]::GetEnvironmentVariable("PATH", "Machine")
              if ($currentPath -notlike "*$installDir*") {
                $newPath = "$currentPath;$installDir"
                [Environment]::SetEnvironmentVariable("PATH", $newPath, "Machine")
                Write-Host "Added DSC to system PATH" -ForegroundColor Cyan
                
                # Refresh environment variables in current session
                $env:PATH = [Environment]::GetEnvironmentVariable("PATH", "Machine") + ";" + [Environment]::GetEnvironmentVariable("PATH", "User")
              }
              
              Write-Host "DSC v3 installed successfully from ZIP" -ForegroundColor Green
              return $true
            }
            else {
              Write-Host "dsc.exe not found in ZIP file" -ForegroundColor Yellow
              return $false
            }
          }
          elseif ($fileExtension -eq ".gz" -or $fileExtension -eq ".tar.gz") {
            # Extract and install from tar.gz (DSC v3 Linux/macOS distribution)
            Write-Host "Extracting and installing DSC v3 from tar.gz file..." -ForegroundColor Cyan
            $extractPath = Join-Path $env:TEMP "DscExtract"
            tar -xzf $LocalInstallerPath -C $extractPath
            
            # DSC v3 is a standalone executable - look for dsc binary
            $dscBinary = Get-ChildItem -Path $extractPath -Recurse -Name "dsc" | Select-Object -First 1
            if ($dscBinary) {
              $dscPath = Join-Path $extractPath $dscBinary
              $dscDir = Split-Path $dscPath -Parent
              
              # Install to /usr/local/bin (Linux/macOS)
              $installDir = "/usr/local/bin"
              if (-not (Test-Path $installDir)) {
                New-Item -Path $installDir -ItemType Directory -Force | Out-Null
              }
              
              # Copy ALL files from the extracted directory to maintain proper structure
              Write-Host "Copying all DSC files to installation directory..." -ForegroundColor Cyan
              Copy-Item -Path "$dscDir\*" -Destination $installDir -Recurse -Force
              chmod +x "$installDir/dsc"
              
              Write-Host "DSC v3 installed successfully from tar.gz" -ForegroundColor Green
              return $true
            }
            else {
              Write-Host "dsc binary not found in tar.gz file" -ForegroundColor Yellow
              return $false
            }
          }
          else {
            Write-Host "Unsupported file type: $fileExtension" -ForegroundColor Yellow
            return $false
          }
        }
        catch {
          Write-Host "Local installer installation failed: $($_.Exception.Message)" -ForegroundColor Yellow
          return $false
        }
      }
      
      # Priority 2: Check if winget is available (only if online installation is allowed)
      if ($AllowOnlineInstallation) {
        try {
          $null = Get-Command 'winget' -ErrorAction Stop
          $useWinget = $true
        }
        catch {
          $useWinget = $false
        }
        
        if ($useWinget) {
          # Try to install using winget
          try {
            Write-Host "Attempting to install DSC v3 using winget..." -ForegroundColor Cyan
            # Try the preview package first (Microsoft.DSC.Preview), then fallback to Microsoft.DSC
            $result = & winget install Microsoft.DSC.Preview --accept-source-agreements --accept-package-agreements 2>&1
            $exitCode = $LASTEXITCODE
            
            if ($exitCode -eq 0) {
              Write-Host "DSC v3 installed successfully using winget (Preview package)" -ForegroundColor Green
              return $true
            }
            else {
              Write-Host "Preview package installation failed, trying main package..." -ForegroundColor Yellow
              $result = & winget install Microsoft.DSC --accept-source-agreements --accept-package-agreements 2>&1
              $exitCode = $LASTEXITCODE
              
              if ($exitCode -eq 0) {
                Write-Host "DSC v3 installed successfully using winget" -ForegroundColor Green
                return $true
              }
              else {
                Write-Host "winget installation failed with exit code $exitCode" -ForegroundColor Yellow
                return $false
              }
            }
          }
          catch {
            Write-Host "winget installation failed: $($_.Exception.Message)" -ForegroundColor Yellow
            return $false
          }
        }
        else {
          # Fallback to direct download and installation (requires internet)
          try {
            Write-Host "Attempting to install DSC v3 using direct download..." -ForegroundColor Cyan
            
            # Download and install DSC v3 using the official GitHub release
            $tempDir = Join-Path $env:TEMP "DscInstall"
            New-Item -Path $tempDir -ItemType Directory -Force | Out-Null
            
            try {
              # Get the latest release information
              $releasesUrl = "https://api.github.com/repos/PowerShell/DSC/releases/latest"
              $release = Invoke-RestMethod -Uri $releasesUrl -Method Get
              
              # Determine platform and architecture
              $platform = if ($IsWindows) { "windows" } elseif ($IsLinux) { "linux" } elseif ($IsMacOS) { "macos" } else { "windows" }
              $arch = if ([Environment]::Is64BitOperatingSystem) { "x86_64" } else { "x86" }
              
              # Find the appropriate asset
              $assetPattern = if ($platform -eq "windows") { "*$arch-pc-windows-msvc.zip" } elseif ($platform -eq "linux") { "*$arch-linux.tar.gz" } else { "*$arch-apple-darwin.tar.gz" }
              $asset = $release.assets | Where-Object { $_.name -like $assetPattern } | Select-Object -First 1
              
              if (-not $asset) {
                Write-Host "No suitable DSC v3 asset found for platform $platform" -ForegroundColor Yellow
                return $false
              }
              
              # Download the asset
              $installerPath = Join-Path $tempDir $asset.name
              Write-Host "Downloading DSC v3 installer: $($asset.name)" -ForegroundColor Cyan
              Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $installerPath -UseBasicParsing
              
              # Install using the same logic as local installer
              $fileExtension = [System.IO.Path]::GetExtension($installerPath).ToLower()
              
              if ($fileExtension -eq ".zip") {
                # Extract and install from ZIP (Windows)
                $extractPath = Join-Path $tempDir "DscExtract"
                Expand-Archive -Path $installerPath -DestinationPath $extractPath -Force
                
                $dscExe = Get-ChildItem -Path $extractPath -Recurse -Name "dsc.exe" | Select-Object -First 1
                if ($dscExe) {
                  $dscPath = Join-Path $extractPath $dscExe
                  $dscDir = Split-Path $dscPath -Parent
                  $installDir = "C:\Program Files\Microsoft DSC"
                  New-Item -Path $installDir -ItemType Directory -Force | Out-Null
                  
                  # Copy ALL files from the extracted directory to maintain proper structure
                  Write-Host "Copying all DSC files to installation directory..." -ForegroundColor Cyan
                  Copy-Item -Path "$dscDir\*" -Destination $installDir -Recurse -Force
                  
                  $currentPath = [Environment]::GetEnvironmentVariable("PATH", "Machine")
                  if ($currentPath -notlike "*$installDir*") {
                    $newPath = "$currentPath;$installDir"
                    [Environment]::SetEnvironmentVariable("PATH", $newPath, "Machine")
                    
                    # Refresh environment variables in current session
                    $env:PATH = [Environment]::GetEnvironmentVariable("PATH", "Machine") + ";" + [Environment]::GetEnvironmentVariable("PATH", "User")
                  }
                  
                  Write-Host "DSC v3 installed successfully from direct download" -ForegroundColor Green
                  return $true
                }
              }
              elseif ($fileExtension -eq ".gz" -or $fileExtension -eq ".tar.gz") {
                # Extract and install from tar.gz (Linux/macOS)
                $extractPath = Join-Path $tempDir "DscExtract"
                tar -xzf $installerPath -C $extractPath
                
                $dscBinary = Get-ChildItem -Path $extractPath -Recurse -Name "dsc" | Select-Object -First 1
                if ($dscBinary) {
                  $dscPath = Join-Path $extractPath $dscBinary
                  $dscDir = Split-Path $dscPath -Parent
                  $installDir = "/usr/local/bin"
                  if (-not (Test-Path $installDir)) {
                    New-Item -Path $installDir -ItemType Directory -Force | Out-Null
                  }
                  
                  # Copy ALL files from the extracted directory to maintain proper structure
                  Write-Host "Copying all DSC files to installation directory..." -ForegroundColor Cyan
                  Copy-Item -Path "$dscDir\*" -Destination $installDir -Recurse -Force
                  chmod +x "$installDir/dsc"
                  
                  Write-Host "DSC v3 installed successfully from direct download" -ForegroundColor Green
                  return $true
                }
              }
              
              Write-Host "Failed to install DSC v3 from downloaded asset" -ForegroundColor Yellow
              return $false
              
            }
            finally {
              # Cleanup temp files
              if (Test-Path $tempDir) {
                Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
              }
            }
          }
          catch {
            Write-Host "Direct download installation failed: $($_.Exception.Message)" -ForegroundColor Yellow
            return $false
          }
        }
      }
      else {
        # No local installer and online installation not allowed
        Write-Host "No local installer provided and online installation is not allowed" -ForegroundColor Red
        return $false
      }
    } -ArgumentList $LocalInstallerPath, $AllowOnlineInstallation
    
    if ($installResult) {
      # Verify installation
      Start-Sleep -Seconds 5  # Give it time to register
      $dscAvailable = Invoke-Command -Session $Session -ScriptBlock {
        try {
          $null = Get-Command 'dsc.exe' -ErrorAction Stop
          return $true
        }
        catch {
          return $false
        }
      }
      
      if ($dscAvailable) {
        if (-not $Quiet) {
          Write-Host "DSC v3 installation verified successfully" -ForegroundColor Green
        }
        return $true
      }
      else {
        throw "DSC v3 installation completed but executable not found in PATH"
      }
    }
    else {
      throw "Failed to install DSC v3 on $TargetComputer"
    }
  }
  catch {
    throw "DSC v3 installation failed on $TargetComputer`: $($_.Exception.Message)"
  }
}

# Create secure remote session with fallback logic
function New-SecureRemoteSession {
  param(
    [string]$TargetComputer,
    [PSCredential]$Credential,
    [switch]$SshTransport,
    [switch]$UseSsl,
  [Nullable[int]]$Port,
    [string]$SshKeyPath,
    [switch]$SkipCertificateValidation,
    [switch]$Quiet
  )
  
  # Determine default port based on transport method
  if (-not $Port) {
    if ($SshTransport) {
      $Port = 22
    }
    elseif ($UseSsl) {
      $Port = 5986
    }
    else {
      $Port = 5985
    }
  }
  
  # Build session parameters
  $sessionParams = @{
    ComputerName = $TargetComputer
    Port         = $Port
  }
  
  # Add credential if provided
  if ($Credential) {
    $sessionParams.Credential = $Credential
  }
  
  # Configure transport method with security priority
  if ($SshTransport) {
    # SSH transport (most secure)
    if (-not $Quiet) {
      Write-Host "Attempting SSH transport connection to $TargetComputer on port $Port..." -ForegroundColor Cyan
    }
    
    $sessionParams.TransportOption = @{
      HostName = $TargetComputer
      Port     = $Port
    }
    
    # Add SSH key if provided
    if ($SshKeyPath) {
      $sessionParams.TransportOption.KeyFilePath = $SshKeyPath
    }
    
    try {
      $session = New-PSSession @sessionParams -ErrorAction Stop
      if (-not $Quiet) {
        Write-Host "SSH transport connection established successfully" -ForegroundColor Green
      }
      return $session
    }
    catch {
      if (-not $Quiet) {
        Write-Host "SSH transport failed: $($_.Exception.Message)" -ForegroundColor Yellow
        Write-Host "Falling back to SSL transport..." -ForegroundColor Yellow
      }
      # Fall back to SSL
      $UseSsl = $true
      $SshTransport = $false
    }
  }
  
  if ($UseSsl) {
    # SSL transport (encrypted WinRM)
    if (-not $Quiet) {
      Write-Host "Attempting SSL transport connection to $TargetComputer on port $Port..." -ForegroundColor Cyan
    }
    
    $sessionParams.UseSSL = $true
    
    # Handle certificate validation
    if ($SkipCertificateValidation) {
      $sessionParams.SessionOption = New-PSSessionOption -SkipCACheck -SkipCNCheck -SkipRevocationCheck
    }
    
    try {
      $session = New-PSSession @sessionParams -ErrorAction Stop
      if (-not $Quiet) {
        Write-Host "SSL transport connection established successfully" -ForegroundColor Green
      }
      return $session
    }
    catch {
      if (-not $Quiet) {
        Write-Host "SSL transport failed: $($_.Exception.Message)" -ForegroundColor Yellow
        Write-Host "Falling back to HTTP transport..." -ForegroundColor Yellow
      }
      # Fall back to HTTP
      $UseSsl = $false
    }
  }
  
  # HTTP transport (least secure, but most compatible)
  if (-not $Quiet) {
    Write-Host "Attempting HTTP transport connection to $TargetComputer on port $Port..." -ForegroundColor Cyan
  }
  
  # Remove SSL-specific parameters
  $sessionParams.Remove('UseSSL')
  $sessionParams.Remove('SessionOption')
  
  try {
    $session = New-PSSession @sessionParams -ErrorAction Stop
    if (-not $Quiet) {
      Write-Host "HTTP transport connection established successfully" -ForegroundColor Green
    }
    return $session
  }
  catch {
    throw "All transport methods failed for $TargetComputer. Last error: $($_.Exception.Message)"
  }
}

# Setup remote execution environment
function Setup-RemoteEnvironment {
  param(
    [string]$TargetComputer, 
    [PSCredential]$Cred, 
    [string]$DscPath, 
    [string]$ParametersPath, 
    [switch]$AutoInstallDsc, 
    [switch]$Quiet, 
    [string]$DscInstallerPath,
    [switch]$AllowOnlineInstallation,
    [switch]$SshTransport,
    [switch]$UseSsl,
  [Nullable[int]]$Port,
    [string]$SshKeyPath,
    [switch]$SkipCertificateValidation
  )
  
  # Use secure session creation with fallback logic
  $session = New-SecureRemoteSession -TargetComputer $TargetComputer -Credential $Cred -SshTransport:$SshTransport -UseSsl:$UseSsl -Port $Port -SshKeyPath $SshKeyPath -SkipCertificateValidation:$SkipCertificateValidation -Quiet:$Quiet
  
  try {
    # Create remote temp directory first
    $remoteTempDir = "C:\Temp\DtbDscHelper"
    Invoke-Command -Session $session -ScriptBlock {
      New-Item -Path $using:remoteTempDir -ItemType Directory -Force | Out-Null
    }
    
    # Check if DSC is available on remote machine FIRST
    $dscAvailable = Invoke-Command -Session $session -ScriptBlock {
      try {
        $null = Get-Command 'dsc.exe' -ErrorAction Stop
        return $true
      }
      catch {
        return $false
      }
    }
    
    # Only install DSC if it's not already available
    if (-not $dscAvailable) {
      if (-not $Quiet) {
        Write-Host "DSC v3 not found on $TargetComputer, installing..." -ForegroundColor Yellow
      }
      
      # Priority 1: Use local installer if provided
      if ($DscInstallerPath -and (Test-Path $DscInstallerPath)) {
        if (-not $Quiet) {
          Write-Host "Copying DSC installer to remote machine..." -ForegroundColor Yellow
        }
        # Copy installer to remote machine temp dir
        $installerFileName = Split-Path $DscInstallerPath -Leaf
        $remoteInstallerPath = Join-Path $remoteTempDir $installerFileName
        Copy-Item -Path $DscInstallerPath -Destination $remoteInstallerPath -ToSession $session -Force
        
        if (-not $Quiet) {
          Write-Host "Installing DSC v3 on $TargetComputer..." -ForegroundColor Yellow
        }
        # Install DSC using the copied installer (remote path)
        $installSuccess = Install-RemoteDsc -Session $session -TargetComputer $TargetComputer -Quiet:$Quiet -LocalInstallerPath $remoteInstallerPath
        if (-not $installSuccess) {
          throw "Failed to install DSC v3 on $TargetComputer using installer. Please check the installer file."
        }
      }
      elseif ($AutoInstallDsc -and $AllowOnlineInstallation) {
        # Priority 2: Attempt to install DSC automatically (this would be online installation)
        $installSuccess = Install-RemoteDsc -Session $session -TargetComputer $TargetComputer -Quiet:$Quiet -AllowOnlineInstallation
        if (-not $installSuccess) {
          throw "Failed to install DSC v3 on $TargetComputer. Please install manually or check prerequisites."
        }
      }
      else {
        throw "DSC executable (dsc.exe) not found on remote machine $TargetComputer. Use -AutoInstallDsc and -AllowRemoteDownload to automatically install DSC v3, or install manually and ensure it's available in PATH."
      }
    }
    else {
      if (-not $Quiet) {
        Write-Host "DSC v3 is already available on $TargetComputer" -ForegroundColor Green
      }
    }
    
    # Copy DSC files to remote machine
    $dscFileName = Split-Path $DscPath -Leaf
    $remoteDscPath = Join-Path $remoteTempDir $dscFileName
    Copy-Item -Path $DscPath -Destination $remoteDscPath -ToSession $session -Force
    
    $remoteParamsPath = $null
    if ($ParametersPath) {
      $paramsFileName = Split-Path $ParametersPath -Leaf
      $remoteParamsPath = Join-Path $remoteTempDir $paramsFileName
      Copy-Item -Path $ParametersPath -Destination $remoteParamsPath -ToSession $session -Force
    }
    
    return @{
      Session          = $session
      RemoteDscPath    = $remoteDscPath
      RemoteParamsPath = $remoteParamsPath
      RemoteTempDir    = $remoteTempDir
    }
  }
  catch {
    Remove-PSSession -Session $session -ErrorAction SilentlyContinue
    throw
  }
}

# Execute DSC on remote machine
function Invoke-RemoteDsc {
  param($RemoteEnv, [string[]]$Arguments, [string]$DscPath, [string]$ParametersPath)
  
  # Update arguments to use remote paths
  $remoteArgs = $Arguments | ForEach-Object {
    if ($_ -eq $DscPath) { $RemoteEnv.RemoteDscPath }
    elseif ($_ -eq $ParametersPath) { $RemoteEnv.RemoteParamsPath }
    else { $_ }
  }
  
  $remoteScript = {
    param($Arguments)
    
    # Debug: Show the arguments being passed
    Write-Host "Debug: Arguments received: $($Arguments | ConvertTo-Json)" -ForegroundColor Magenta
    Write-Host "Debug: Arguments type: $($Arguments.GetType().Name)" -ForegroundColor Magenta
    Write-Host "Debug: Arguments count: $($Arguments.Count)" -ForegroundColor Magenta
    
    # If Arguments is a single string, split it into an array
    if ($Arguments -is [string]) {
      $Arguments = $Arguments -split ' '
      Write-Host "Debug: Arguments split into array: $($Arguments | ConvertTo-Json)" -ForegroundColor Magenta
    }
    
    # Initialize DSC environment for remote session
    $env:DSC_TRACE = "0"  # Disable tracing to avoid the error
    $env:DSC_LOG_LEVEL = "error"  # Only show errors
    
    # Ensure PATH is refreshed in this session (in case DSC was just installed)
    $env:PATH = [Environment]::GetEnvironmentVariable("PATH", "Machine") + ";" + [Environment]::GetEnvironmentVariable("PATH", "User")
    
    # Execute DSC command on remote machine
    $cmdLine = "dsc $($Arguments -join ' ')"
    Write-Host "Executing on $env:COMPUTERNAME: $cmdLine" -ForegroundColor Cyan
    
    try {
      $output = & dsc @Arguments 2>&1
      $exitCode = $LASTEXITCODE
      
      Write-Host "Exit Code: $exitCode" -ForegroundColor $(if ($exitCode -eq 0) { 'Green' } else { 'Red' })
      
      if ($exitCode -eq 0) {
        # Handle empty output (common with validate operation)
        if ([string]::IsNullOrWhiteSpace($output)) {
          return "{}"  # Return empty JSON object
        }
        # Filter out any non-JSON output (like the tracing error messages)
        $jsonLines = $output | Where-Object { $_ -match '^[{\[].*[}\]]$' -or $_ -match '^[{\[].*$' -or $_ -match '.*[}\]]$' }
        if ($jsonLines) {
          return ($jsonLines -join "`n")
        }
        else {
          return "{}"  # Return empty JSON object if no valid JSON found
        }
      }
      else {
        throw "DSC command failed with exit code $exitCode`: $output"
      }
    }
    catch {
      throw "Failed to execute DSC command: $($_.Exception.Message)"
    }
  }
  
  # Always pass arguments as an array
  return Invoke-Command -Session $RemoteEnv.Session -ArgumentList @(, $remoteArgs) -ScriptBlock $remoteScript
}

# Parse DSC configuration file to extract resource types
function Get-DscResourceTypes {
  param([string]$DscPath)
  
  try {
    $content = Get-Content -Path $DscPath -Raw
    $yaml = $content | ConvertFrom-Yaml
    
    $resourceTypes = @()
    
    if ($yaml.resources) {
      foreach ($resource in $yaml.resources) {
        if ($resource.type) {
          $resourceTypes += $resource.type
        }
      }
    }
    
    return $resourceTypes | Sort-Object -Unique
  }
  catch {
    Write-Warning "Failed to parse DSC configuration file for resource types: $($_.Exception.Message)"
    return @()
  }
}

# Check if DSC resources are available on remote machine
function Test-DscResources {
  param([System.Management.Automation.Runspaces.PSSession]$Session, [string[]]$ResourceTypes, [switch]$Quiet)
  
  $missingResources = @()
  
  # First, get all available resources on the remote machine
  $availableResources = Invoke-Command -Session $Session -ScriptBlock {
    try {
      # Initialize DSC environment for remote session
      $env:DSC_TRACE = "0"  # Disable tracing to avoid the error
      $env:DSC_LOG_LEVEL = "error"  # Only show errors
      
      # Get all available resources
      $result = & dsc resource list --output-format json 2>&1
      if ($LASTEXITCODE -eq 0) {
        $resources = $result | ConvertFrom-Json
        return $resources
      }
      else {
        Write-Host "Failed to get resource list: $result" -ForegroundColor Yellow
        return @()
      }
    }
    catch {
      Write-Host "Exception getting resource list: $($_.Exception.Message)" -ForegroundColor Yellow
      return @()
    }
  }
  
  if (-not $Quiet) {
    Write-Host "Available resources on remote machine: $($availableResources.Count)" -ForegroundColor Cyan
  }
  
  # Check each required resource type
  foreach ($resourceType in $ResourceTypes) {
    $found = $false
    
    # Try exact match first
    foreach ($resource in $availableResources) {
      if ($resource.type -eq $resourceType) {
        $found = $true
        break
      }
    }
    
    # If not found, try partial matches (for cases where the resource name might be different)
    if (-not $found) {
      # Extract the resource name part (after the last slash)
      $resourceName = $resourceType -replace '^.*/', ''
      
      foreach ($resource in $availableResources) {
        if ($resource.type -like "*$resourceName*" -or $resource.type -like "*$resourceType*") {
          $found = $true
          if (-not $Quiet) {
            Write-Host "Found resource '$resourceType' as '$($resource.type)'" -ForegroundColor Green
          }
          break
        }
      }
    }
    
    if (-not $found) {
      $missingResources += $resourceType
      if (-not $Quiet) {
        Write-Host "Resource not available: $resourceType" -ForegroundColor Yellow
      }
    }
    else {
      if (-not $Quiet) {
        Write-Host "Resource available: $resourceType" -ForegroundColor Green
      }
    }
  }
  
  return $missingResources
}

# Install DSC resources on remote machine using offline packages
function Install-DscResources {
  param([System.Management.Automation.Runspaces.PSSession]$Session, [string[]]$ResourceTypes, [switch]$Quiet)
  
  foreach ($resourceType in $ResourceTypes) {
    if (-not $Quiet) {
      Write-Host "Installing DSC resource: $resourceType" -ForegroundColor Yellow
    }
    
    # Get local resource package
    $localResourcePath = Get-DscResourcePath -ResourceType $resourceType -Quiet:$Quiet
    if (-not $localResourcePath) {
      Write-Warning "No cached resource package found for $resourceType. Run Update-DscResourceCache first to download resources locally."
      continue
    }
    
    $installResult = Invoke-Command -Session $Session -ScriptBlock {
      param($ResourceType, $LocalResourcePath)
      
      try {
        # Initialize DSC environment for remote session
        $env:DSC_TRACE = "0"  # Disable tracing to avoid the error
        $env:DSC_LOG_LEVEL = "error"  # Only show errors
        
        Write-Host "Installing DSC resource $ResourceType from local package..." -ForegroundColor Cyan
        
        # Extract resource package
        $tempDir = Join-Path $env:TEMP "DscResourceInstall"
        New-Item -Path $tempDir -ItemType Directory -Force | Out-Null
        
        try {
          # Extract the resource package
          Expand-Archive -Path $LocalResourcePath -DestinationPath $tempDir -Force
          
          # Determine DSC installation directory
          $dscExePath = (Get-Command 'dsc.exe' -ErrorAction SilentlyContinue).Source
          if ($dscExePath) {
            $dscDir = Split-Path $dscExePath -Parent
          }
          else {
            # Fallback to default installation path
            $dscDir = "C:\Program Files\Microsoft DSC"
          }
          
          # Ensure DSC directory exists
          if (-not (Test-Path $dscDir)) {
            New-Item -Path $dscDir -ItemType Directory -Force | Out-Null
            Write-Host "Created DSC installation directory: $dscDir" -ForegroundColor Cyan
          }
          
          # Copy resource files to DSC directory
          $resourceFiles = Get-ChildItem -Path $tempDir -Recurse -File
          $copiedCount = 0
          
          foreach ($file in $resourceFiles) {
            $relativePath = $file.FullName.Substring($tempDir.Length + 1)
            $targetPath = Join-Path $dscDir $relativePath
            $targetDir = Split-Path $targetPath -Parent
            
            if (-not (Test-Path $targetDir)) {
              New-Item -Path $targetDir -ItemType Directory -Force | Out-Null
            }
            
            Copy-Item -Path $file.FullName -Destination $targetPath -Force
            $copiedCount++
          }
          
          Write-Host "Successfully installed resource: $ResourceType ($copiedCount files copied)" -ForegroundColor Green
          return $true
          
        }
        finally {
          # Cleanup temp directory
          if (Test-Path $tempDir) {
            Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
          }
        }
        
      }
      catch {
        Write-Host "Exception installing resource $ResourceType`: $($_.Exception.Message)" -ForegroundColor Yellow
        return $false
      }
    } -ArgumentList $resourceType, $localResourcePath
    
    if (-not $installResult) {
      Write-Warning "Failed to install DSC resource: $resourceType"
    }
    else {
      if (-not $Quiet) {
        Write-Host "✓ Successfully installed DSC resource: $resourceType" -ForegroundColor Green
      }
    }
  }
}

# Cleanup remote environment
function Cleanup-RemoteEnvironment {
  param($RemoteEnv)
  
  if ($RemoteEnv.Session) {
    try {
      # Clean up temp files
      Invoke-Command -Session $RemoteEnv.Session -ScriptBlock {
        if (Test-Path $using:RemoteEnv.RemoteTempDir) {
          Remove-Item -Path $using:RemoteEnv.RemoteTempDir -Recurse -Force -ErrorAction SilentlyContinue
        }
      }
    }
    catch {
      # Ignore cleanup errors
    }
    finally {
      Remove-PSSession -Session $RemoteEnv.Session -ErrorAction SilentlyContinue
    }
  }
}

function Invoke-DscHelper {
  <#
    .SYNOPSIS
        Executes DSC v3 commands with improved parameter validation and user guidance.
    .DESCRIPTION
        Provides a user-friendly interface to DSC v3 operations with validated parameters,
        helpful error messages, and support for both local and remote execution.
        Automatically handles remote execution without requiring manual setup on remote machines.
        This function provides full parameter autocomplete support in PowerShell 7.
    .PARAMETER DscPath
        Path to the DSC configuration YAML file.
    .PARAMETER Operation
        The DSC operation to perform. Valid values: 'Set', 'Test', 'Validate', 'Export'.
    .PARAMETER ParametersPath
        Optional path to parameters JSON/YAML file for the configuration.
    .PARAMETER ComputerName
        Target computer name for remote execution. Defaults to local machine.
    .PARAMETER ReturnInDesiredState
        When specified, returns only the InDesiredState property from the result.
    .PARAMETER Quiet
        Suppresses verbose output during execution.
    .PARAMETER WhatIf
        Shows what would happen without making changes (only applies to 'Set' operation).
    .PARAMETER Credential
        Credential for remote connection (optional).
    .PARAMETER SshTransport
        Use SSH transport for remote connections (more secure, requires SSH server on target).
    .PARAMETER UseSsl
        Use SSL/TLS for remote connections (encrypts communication).
    .PARAMETER Port
        Port number for remote connection (default: 5985 for HTTP, 5986 for HTTPS, 22 for SSH).
    .PARAMETER SshKeyPath
        SSH key file path for SSH transport authentication.
    .PARAMETER SkipCertificateValidation
        Skip certificate validation for HTTPS connections (not recommended for production).
    .EXAMPLE
        Invoke-DscHelper -DscPath "C:\Configs\WebServer.yaml" -Operation "Test"
    .EXAMPLE
        Invoke-DscHelper -DscPath "C:\Configs\Cluster.yaml" -Operation "Set" -ParametersPath "C:\Configs\params.json" -ComputerName "SERVER01"
    .EXAMPLE
        Invoke-DscHelper -DscPath "C:\Configs\Baseline.yaml" -Operation "Set" -WhatIf
    .EXAMPLE
        # Test compliance and return only the desired state
        $inDesiredState = Invoke-DscHelper -DscPath "C:\Configs\WebServer.yaml" -Operation "Test" -ReturnInDesiredState
    .EXAMPLE
        # Use SSH transport for secure remote connection
        Invoke-DscHelper -DscPath "C:\Configs\WebServer.yaml" -Operation "Test" -ComputerName "server01" -SshTransport -SshKeyPath "C:\keys\id_rsa"
    .EXAMPLE
        # Use SSL for encrypted WinRM connection
        Invoke-DscHelper -DscPath "C:\Configs\WebServer.yaml" -Operation "Test" -ComputerName "server01" -UseSsl -Port 5986
    .OUTPUTS
        [PSCustomObject] or [bool] depending on ReturnInDesiredState parameter
    .LINK
        https://docs.microsoft.com/en-us/powershell/dsc/overview
    #>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $true, 
      Position = 0,
      HelpMessage = 'Path to the DSC configuration YAML file')]
    [ValidateNotNullOrEmpty()]
    [ValidateScript({ Test-Path $_ -PathType Leaf })]
    [Alias('Path', 'ConfigPath')]
    [string]$DscPath,
        
    [Parameter(Mandatory = $true, 
      Position = 1,
      HelpMessage = 'DSC operation to perform. Valid values: Set (apply config), Test (check compliance), Validate (validate config), Export (export current state)')]
    [ValidateSet('Set', 'Test', 'Validate', 'Export', 
      IgnoreCase = $true)]
    [Alias('Op', 'Action')]
    [string]$Operation,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Path to parameters JSON/YAML file')]
    [ValidateScript({ -not $_ -or (Test-Path $_ -PathType Leaf) })]
    [Alias('Params', 'ParamFile')]
    [string]$ParametersPath,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Target computer name for remote execution. If not specified or matches current computer, runs locally.')]
    [Alias('Computer', 'Target', 'Server')]
    [string]$ComputerName = $env:COMPUTERNAME,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Return only the InDesiredState property')]
    [Alias('ReturnState', 'StateOnly')]
    [switch]$ReturnInDesiredState,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Suppress verbose output')]
    [Alias('Silent')]
    [switch]$Quiet,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Show what would happen without making changes (Set operation only)')]
    [Alias('Preview', 'DryRun')]
    [switch]$WhatIf,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Credential for remote connection (only needed for remote execution)')]
    [Alias('Cred')]
    [PSCredential]$Credential,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Automatically install DSC v3 on remote machine if not available (default: true)')]
    [Alias('AutoInstall')]
    [bool]$AutoInstallDsc = $true,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Path to local DSC v3 MSI installer for offline installation. If not specified, uses cached installer from module.')]
    [ValidateScript({ -not $_ -or (Test-Path $_ -PathType Leaf) })]
    [Alias('InstallerPath', 'OfflineInstaller')]
    [string]$DscInstallerPath,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Preferred DSC version to use for installation')]
    [Alias('Version')]
    [string]$PreferredDscVersion,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Force update of DSC installer cache')]
    [Alias('ForceUpdate')]
    [switch]$ForceUpdateCache,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Allow remote system to download DSC installer if cached version is not available')]
    [Alias('AllowOnlineInstall', 'OnlineInstall')]
    [switch]$AllowRemoteDownload,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Use SSH transport for remote connections (more secure, requires SSH server on target)')]
    [Alias('SSH')]
    [switch]$SshTransport,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Use SSL/TLS for remote connections (encrypts communication)')]
    [Alias('SSL')]
    [switch]$UseSsl,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Port number for remote connection (default: 5985 for HTTP, 5986 for HTTPS, 22 for SSH)')]
    [ValidateScript({ -not $_ -or ($_ -ge 1 -and $_ -le 65535) })]
    [Nullable[int]]$Port,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'SSH key file path for SSH transport authentication')]
    [ValidateScript({ -not $_ -or (Test-Path $_ -PathType Leaf) })]
    [Alias('SSHKey')]
    [string]$SshKeyPath,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Skip certificate validation for HTTPS connections (not recommended for production)')]
    [Alias('SkipCertCheck')]
    [switch]$SkipCertificateValidation,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Automatically install required DSC resources on remote machine if not available (default: true)')]
    [Alias('AutoInstallResources')]
    [bool]$AutoInstallDscResources = $true,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Skip checking for required DSC resources (useful when resources are known to be available)')]
    [Alias('SkipResources')]
    [switch]$SkipResourceCheck
  )

  # Main execution logic
  try {
    # Pre-flight checks
    Test-DscExecutable
    Test-DscPaths -DscPath $DscPath -ParametersPath $ParametersPath
    
    # Build arguments
    $dscArgs = Build-DscArguments -Operation $Operation -DscPath $DscPath -ParametersPath $ParametersPath -WhatIf:$WhatIf
    
    # Determine if we need to run remotely
    $isRemote = $ComputerName -ne $env:COMPUTERNAME
    
    # Auto-select most secure transport method if none specified
    if ($isRemote -and -not $SshTransport -and -not $UseSsl) {
      # Try to determine the most secure method available
      if (-not $Quiet) {
        Write-Host "No transport method specified, attempting to auto-select most secure method..." -ForegroundColor Cyan
      }
      
      # Check if SSH is available (most secure)
      try {
        $sshTest = New-PSSession -HostName $ComputerName -Port 22 -ErrorAction Stop -TimeoutSec 5
        Remove-PSSession -Session $sshTest -ErrorAction SilentlyContinue
        $SshTransport = $true
        if (-not $Quiet) {
          Write-Host "SSH transport detected as available, using SSH for secure connection" -ForegroundColor Green
        }
      }
      catch {
        # SSH not available, try SSL
        try {
          $sslTest = New-PSSession -ComputerName $ComputerName -Port 5986 -UseSSL -ErrorAction Stop -TimeoutSec 5
          Remove-PSSession -Session $sslTest -ErrorAction SilentlyContinue
          $UseSsl = $true
          if (-not $Quiet) {
            Write-Host "SSL transport detected as available, using SSL for encrypted connection" -ForegroundColor Green
          }
        }
        catch {
          # Fall back to HTTP (least secure but most compatible)
          if (-not $Quiet) {
            Write-Host "No secure transport detected, using HTTP transport (consider configuring SSH or SSL for better security)" -ForegroundColor Yellow
          }
        }
      }
    }
    
    if ($isRemote) {
      # Remote execution - automatically handle setup
      if (-not $Quiet) {
        Write-Host "Setting up remote execution on: $ComputerName" -ForegroundColor Yellow
      }
      
      # Handle installer (cached or provided) BEFORE setting up remote environment
      $installerToUse = $DscInstallerPath
      
      # If no specific installer provided, try to use cached installer
      if (-not $installerToUse) {
        if (-not $Quiet) {
          Write-Host "Checking for cached DSC installer..." -ForegroundColor Yellow
        }
        
        # Always check for updates daily (but don't force download)
        Update-DscInstallerCacheInternal -Quiet:$Quiet
        
        # Force update cache if requested
        if ($ForceUpdateCache) {
          Write-Host "Force updating DSC installer cache..." -ForegroundColor Yellow
          Update-DscInstallerCacheInternal -Force -Quiet:$Quiet
        }
        
        # For now, assume Windows platform (we'll detect properly after connection)
        $targetPlatform = "Windows"
        
        if (-not $Quiet) {
          Write-Host "Checking for cached DSC installer for platform: $targetPlatform" -ForegroundColor Cyan
        }
        
        $installerToUse = Get-DscInstallerPath -PreferredVersion $PreferredDscVersion -TargetPlatform $targetPlatform -Quiet:$Quiet
        if ($installerToUse) {
          if (-not $Quiet) {
            Write-Host "Using cached DSC installer: $installerToUse" -ForegroundColor Green
          }
        }
        else {
          # If no cached installer and online installation not allowed, throw error
          if (-not $AllowRemoteDownload) {
            $cache = Get-InstallerCache
            $availableVersions = if ($cache.AvailableVersions.PSObject.Properties.Name) { $cache.AvailableVersions.PSObject.Properties.Name -join ', ' } else { 'none' }
            throw "No cached DSC installer found and remote download is not allowed.`n`nAvailable versions in cache: $availableVersions`n`nTo resolve this:`n1. Run 'Update-DscInstallerCache' to download installers locally, OR`n2. Use -AllowRemoteDownload parameter to enable online installation, OR`n3. Provide a local installer path with -DscInstallerPath parameter"
          }
        }
      }
      
      # Setup remote environment with installer path
      $remoteEnv = Setup-RemoteEnvironment -TargetComputer $ComputerName -Cred $Credential -DscPath $DscPath -ParametersPath $ParametersPath -AutoInstallDsc:$AutoInstallDsc -Quiet:$Quiet -DscInstallerPath $installerToUse -AllowOnlineInstallation:$AllowRemoteDownload -SshTransport:$SshTransport -UseSsl:$UseSsl -Port $Port -SshKeyPath $SshKeyPath -SkipCertificateValidation:$SkipCertificateValidation
      
      # Auto-install DSC resources if enabled and not skipped
      if ($AutoInstallDscResources -and -not $SkipResourceCheck) {
        $resourceTypes = Get-DscResourceTypes -DscPath $DscPath
        if ($resourceTypes.Count -gt 0) {
          if (-not $Quiet) { Write-Host "Checking for required DSC resources on remote machine..." -ForegroundColor Yellow }
          $missingResources = Test-DscResources -Session $remoteEnv.Session -ResourceTypes $resourceTypes -Quiet:$Quiet
          if ($missingResources.Count -gt 0) {
            if (-not $Quiet) { Write-Host "Installing missing DSC resources: $($missingResources -join ', ')" -ForegroundColor Yellow }
            Install-DscResources -Session $remoteEnv.Session -ResourceTypes $missingResources -Quiet:$Quiet
          }
          else {
            if (-not $Quiet) { Write-Host "All required DSC resources are already installed on remote machine." -ForegroundColor Green }
          }
        }
      }
      elseif ($SkipResourceCheck) {
        if (-not $Quiet) { Write-Host "Skipping DSC resource check as requested" -ForegroundColor Cyan }
      }
      

      
      try {
        # Execute DSC on remote machine
  $jsonString = Invoke-RemoteDsc -RemoteEnv $remoteEnv -Arguments $dscArgs -DscPath $DscPath -ParametersPath $ParametersPath
  $result = Convert-FromDscJson -Output $jsonString
      }
      finally {
        Cleanup-RemoteEnvironment -RemoteEnv $remoteEnv
      }
    }
    else {
      # Local execution
      $dscResult = Invoke-DscCommand -Arguments $dscArgs -TargetComputer $env:COMPUTERNAME -Quiet:$Quiet
            
      if ($dscResult.ExitCode -eq 0) {
        $result = Convert-FromDscJson -Output $dscResult.Output
      }
      else {
        throw "DSC command failed with exit code $($dscResult.ExitCode): $($dscResult.Output)"
      }
    }
        
    # Handle ReturnInDesiredState parameter
    if ($ReturnInDesiredState) {
      if ($null -ne $result.inDesiredState) { 
        return $result.inDesiredState 
      }
      elseif ($null -ne $result.InDesiredState) { 
        return $result.InDesiredState 
      }
      else {
        Write-Warning "InDesiredState property not found in DSC result"
        return $null
      }
    }
        
    return $result
  }
  catch {
    Write-Error "DSC Helper failed: $($_.Exception.Message)"
    throw
  }
}

# Additional helper functions for common DSC operations

function Test-DscConfiguration {
  <#
    .SYNOPSIS
        Tests DSC configuration compliance without making changes.
    .DESCRIPTION
        Wrapper around Invoke-DscHelper for testing compliance. Returns true if in desired state.
        Automatically handles remote execution without manual setup on remote machines.
    .PARAMETER DscPath
        Path to the DSC configuration YAML file.
    .PARAMETER ParametersPath
        Optional path to parameters JSON/YAML file.
    .PARAMETER ComputerName
        Target computer name for remote execution.
    .PARAMETER Credential
        Credential for remote connection (optional).
    .EXAMPLE
        Test-DscCompliance -DscPath "C:\Configs\WebServer.yaml"
    .EXAMPLE
        Test-DscCompliance -DscPath "C:\Configs\Cluster.yaml" -ComputerName "SERVER01"
    .OUTPUTS
        [bool] True if in desired state, false otherwise.
    #>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $true, 
      Position = 0,
      HelpMessage = 'Path to the DSC configuration YAML file')]
    [ValidateNotNullOrEmpty()]
    [ValidateScript({ Test-Path $_ -PathType Leaf })]
    [Alias('Path', 'ConfigPath')]
    [string]$DscPath,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Path to parameters JSON/YAML file')]
    [ValidateScript({ -not $_ -or (Test-Path $_ -PathType Leaf) })]
    [Alias('Params', 'ParamFile')]
    [string]$ParametersPath,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Target computer name for remote execution. If not specified or matches current computer, runs locally.')]
    [ValidateNotNullOrEmpty()]
    [Alias('Computer', 'Target', 'Server')]
    [string]$ComputerName = $env:COMPUTERNAME,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Credential for remote connection (only needed for remote execution)')]
    [Alias('Cred')]
    [PSCredential]$Credential,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Automatically install DSC v3 on remote machine if not available (default: true)')]
  [Alias('AutoInstall')]
  [bool]$AutoInstallDsc = $true,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Path to local DSC v3 MSI installer for offline installation. If not specified, uses cached installer from module.')]
    [ValidateScript({ -not $_ -or (Test-Path $_ -PathType Leaf) })]
    [Alias('InstallerPath', 'OfflineInstaller')]
    [string]$DscInstallerPath,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Preferred DSC version to use for installation')]
    [Alias('Version')]
    [string]$PreferredDscVersion,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Force update of DSC installer cache')]
    [Alias('ForceUpdate')]
    [switch]$ForceUpdateCache,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Allow remote system to download DSC installer if cached version is not available')]
    [Alias('AllowOnlineInstall', 'OnlineInstall')]
    [switch]$AllowRemoteDownload,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Use SSH transport for remote connections (more secure, requires SSH server on target)')]
    [Alias('SSH')]
    [switch]$SshTransport,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Use SSL/TLS for remote connections (encrypts communication)')]
    [Alias('SSL')]
    [switch]$UseSsl,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Port number for remote connection (default: 5985 for HTTP, 5986 for HTTPS, 22 for SSH)')]
    [ValidateScript({ -not $_ -or ($_ -ge 1 -and $_ -le 65535) })]
    [Nullable[int]]$Port,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'SSH key file path for SSH transport authentication')]
    [ValidateNotNullOrEmpty()]
    [ValidateScript({ -not $_ -or (Test-Path $_ -PathType Leaf) })]
    [Alias('SSHKey')]
    [string]$SshKeyPath,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Skip certificate validation for HTTPS connections (not recommended for production)')]
    [Alias('SkipCertCheck')]
    [switch]$SkipCertificateValidation,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Automatically install required DSC resources on remote machine if not available (default: true)')]
  [Alias('AutoInstallResources')]
  [bool]$AutoInstallDscResources = $true,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Skip checking for required DSC resources (useful when resources are known to be available)')]
    [Alias('SkipResources')]
    [switch]$SkipResourceCheck
  )
    
  $invokeArgs = @{ DscPath = $DscPath; Operation = 'Test'; ComputerName = $ComputerName; ReturnInDesiredState = $true }
  if ($PSBoundParameters.ContainsKey('ParametersPath')) { $invokeArgs.ParametersPath = $ParametersPath }
  if ($PSBoundParameters.ContainsKey('Credential')) { $invokeArgs.Credential = $Credential }
  if ($PSBoundParameters.ContainsKey('AutoInstallDsc')) { $invokeArgs.AutoInstallDsc = $AutoInstallDsc }
  if ($PSBoundParameters.ContainsKey('DscInstallerPath')) { $invokeArgs.DscInstallerPath = $DscInstallerPath }
  if ($PSBoundParameters.ContainsKey('PreferredDscVersion')) { $invokeArgs.PreferredDscVersion = $PreferredDscVersion }
  if ($PSBoundParameters.ContainsKey('ForceUpdateCache')) { $invokeArgs.ForceUpdateCache = $ForceUpdateCache }
  if ($PSBoundParameters.ContainsKey('AllowRemoteDownload')) { $invokeArgs.AllowRemoteDownload = $AllowRemoteDownload }
  if ($PSBoundParameters.ContainsKey('SshTransport')) { $invokeArgs.SshTransport = $SshTransport }
  if ($PSBoundParameters.ContainsKey('UseSsl')) { $invokeArgs.UseSsl = $UseSsl }
  if ($PSBoundParameters.ContainsKey('Port')) { $invokeArgs.Port = $Port }
  if ($PSBoundParameters.ContainsKey('SshKeyPath')) { $invokeArgs.SshKeyPath = $SshKeyPath }
  if ($PSBoundParameters.ContainsKey('SkipCertificateValidation')) { $invokeArgs.SkipCertificateValidation = $SkipCertificateValidation }
  if ($PSBoundParameters.ContainsKey('AutoInstallDscResources')) { $invokeArgs.AutoInstallDscResources = $AutoInstallDscResources }
  if ($PSBoundParameters.ContainsKey('SkipResourceCheck')) { $invokeArgs.SkipResourceCheck = $SkipResourceCheck }
  return Invoke-DscHelper @invokeArgs
}

function Set-DscConfiguration {
  <#
    .SYNOPSIS
        Applies a DSC configuration to make changes.
    .DESCRIPTION
        Wrapper around Invoke-DscHelper for applying configurations.
        Automatically handles remote execution without manual setup on remote machines.
    .PARAMETER DscPath
        Path to the DSC configuration YAML file.
    .PARAMETER ParametersPath
        Optional path to parameters JSON/YAML file.
    .PARAMETER ComputerName
        Target computer name for remote execution.
    .PARAMETER WhatIf
        Show what would happen without making changes.
    .PARAMETER Credential
        Credential for remote connection (optional).
    .EXAMPLE
        Set-DscConfiguration -DscPath "C:\Configs\WebServer.yaml"
    .EXAMPLE
        Set-DscConfiguration -DscPath "C:\Configs\Cluster.yaml" -ComputerName "SERVER01" -WhatIf
    #>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $true, 
      Position = 0,
      HelpMessage = 'Path to the DSC configuration YAML file')]
    [ValidateNotNullOrEmpty()]
    [ValidateScript({ Test-Path $_ -PathType Leaf })]
    [Alias('Path', 'ConfigPath')]
    [string]$DscPath,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Path to parameters JSON/YAML file')]
    [ValidateScript({ -not $_ -or (Test-Path $_ -PathType Leaf) })]
    [Alias('Params', 'ParamFile')]
    [string]$ParametersPath,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Target computer name for remote execution. If not specified or matches current computer, runs locally.')]
    [ValidateNotNullOrEmpty()]
    [Alias('Computer', 'Target', 'Server')]
    [string]$ComputerName = $env:COMPUTERNAME,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Show what would happen without making changes')]
    [Alias('Preview', 'DryRun')]
    [switch]$WhatIf,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Credential for remote connection (only needed for remote execution)')]
    [Alias('Cred')]
    [PSCredential]$Credential,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Automatically install DSC v3 on remote machine if not available (default: true)')]
    [Alias('AutoInstall')]
    [bool]$AutoInstallDsc = $true,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Path to local DSC v3 MSI installer for offline installation. If not specified, uses cached installer from module.')]
    [ValidateScript({ -not $_ -or (Test-Path $_ -PathType Leaf) })]
    [Alias('InstallerPath', 'OfflineInstaller')]
    [string]$DscInstallerPath,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Preferred DSC version to use for installation')]
    [Alias('Version')]
    [string]$PreferredDscVersion,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Force update of DSC installer cache')]
    [Alias('ForceUpdate')]
    [switch]$ForceUpdateCache,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Allow remote system to download DSC installer if cached version is not available')]
    [Alias('AllowOnlineInstall', 'OnlineInstall')]
    [switch]$AllowRemoteDownload,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Use SSH transport for remote connections (more secure, requires SSH server on target)')]
    [Alias('SSH')]
    [switch]$SshTransport,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Use SSL/TLS for remote connections (encrypts communication)')]
    [Alias('SSL')]
    [switch]$UseSsl,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Port number for remote connection (default: 5985 for HTTP, 5986 for HTTPS, 22 for SSH)')]
    [ValidateScript({ -not $_ -or ($_ -ge 1 -and $_ -le 65535) })]
    [Nullable[int]]$Port,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'SSH key file path for SSH transport authentication')]
    [ValidateNotNullOrEmpty()]
    [ValidateScript({ -not $_ -or (Test-Path $_ -PathType Leaf) })]
    [Alias('SSHKey')]
    [string]$SshKeyPath,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Skip certificate validation for HTTPS connections (not recommended for production)')]
    [Alias('SkipCertCheck')]
    [switch]$SkipCertificateValidation,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Automatically install required DSC resources on remote machine if not available (default: true)')]
    [Alias('AutoInstallResources')]
    [bool]$AutoInstallDscResources = $true,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Skip checking for required DSC resources (useful when resources are known to be available)')]
    [Alias('SkipResources')]
    [switch]$SkipResourceCheck
  )
    
  $invokeArgs = @{ DscPath = $DscPath; Operation = 'Set'; ComputerName = $ComputerName }
  if ($PSBoundParameters.ContainsKey('ParametersPath')) { $invokeArgs.ParametersPath = $ParametersPath }
  if ($PSBoundParameters.ContainsKey('Credential')) { $invokeArgs.Credential = $Credential }
  if ($PSBoundParameters.ContainsKey('WhatIf')) { $invokeArgs.WhatIf = $WhatIf }
  if ($PSBoundParameters.ContainsKey('AutoInstallDsc')) { $invokeArgs.AutoInstallDsc = $AutoInstallDsc }
  if ($PSBoundParameters.ContainsKey('DscInstallerPath')) { $invokeArgs.DscInstallerPath = $DscInstallerPath }
  if ($PSBoundParameters.ContainsKey('PreferredDscVersion')) { $invokeArgs.PreferredDscVersion = $PreferredDscVersion }
  if ($PSBoundParameters.ContainsKey('ForceUpdateCache')) { $invokeArgs.ForceUpdateCache = $ForceUpdateCache }
  if ($PSBoundParameters.ContainsKey('AllowRemoteDownload')) { $invokeArgs.AllowRemoteDownload = $AllowRemoteDownload }
  if ($PSBoundParameters.ContainsKey('SshTransport')) { $invokeArgs.SshTransport = $SshTransport }
  if ($PSBoundParameters.ContainsKey('UseSsl')) { $invokeArgs.UseSsl = $UseSsl }
  if ($PSBoundParameters.ContainsKey('Port')) { $invokeArgs.Port = $Port }
  if ($PSBoundParameters.ContainsKey('SshKeyPath')) { $invokeArgs.SshKeyPath = $SshKeyPath }
  if ($PSBoundParameters.ContainsKey('SkipCertificateValidation')) { $invokeArgs.SkipCertificateValidation = $SkipCertificateValidation }
  if ($PSBoundParameters.ContainsKey('AutoInstallDscResources')) { $invokeArgs.AutoInstallDscResources = $AutoInstallDscResources }
  if ($PSBoundParameters.ContainsKey('SkipResourceCheck')) { $invokeArgs.SkipResourceCheck = $SkipResourceCheck }
  return Invoke-DscHelper @invokeArgs
}

function Validate-DscConfiguration {
  <#
    .SYNOPSIS
        Validates a DSC configuration file.
    .DESCRIPTION
        Wrapper around Invoke-DscHelper for validating configuration files.
        Automatically handles remote execution without manual setup on remote machines.
    .PARAMETER DscPath
        Path to the DSC configuration YAML file.
    .PARAMETER ComputerName
        Target computer name for remote execution.
    .PARAMETER Credential
        Credential for remote connection (optional).
    .EXAMPLE
        Validate-DscConfiguration -DscPath "C:\Configs\WebServer.yaml"
    .EXAMPLE
        Validate-DscConfiguration -DscPath "C:\Configs\Cluster.yaml" -ComputerName "SERVER01"
    #>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $true, 
      Position = 0,
      HelpMessage = 'Path to the DSC configuration YAML file')]
    [ValidateNotNullOrEmpty()]
    [ValidateScript({ Test-Path $_ -PathType Leaf })]
    [Alias('Path', 'ConfigPath')]
    [string]$DscPath,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Target computer name for remote execution. If not specified or matches current computer, runs locally.')]
    [Alias('Computer', 'Target', 'Server')]
    [string]$ComputerName = $env:COMPUTERNAME,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Credential for remote connection (only needed for remote execution)')]
    [Alias('Cred')]
    [PSCredential]$Credential,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Automatically install DSC v3 on remote machine if not available (default: true)')]
    [Alias('AutoInstall')]
    [bool]$AutoInstallDsc = $true,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Path to local DSC v3 MSI installer for offline installation. If not specified, uses cached installer from module.')]
  [ValidateScript({ -not $_ -or (Test-Path $_ -PathType Leaf) })]
    [Alias('InstallerPath', 'OfflineInstaller')]
    [string]$DscInstallerPath,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Preferred DSC version to use for installation')]
    [Alias('Version')]
    [string]$PreferredDscVersion,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Force update of DSC installer cache')]
    [Alias('ForceUpdate')]
    [switch]$ForceUpdateCache,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Allow remote system to download DSC installer if cached version is not available')]
    [Alias('AllowOnlineInstall', 'OnlineInstall')]
    [switch]$AllowRemoteDownload,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Use SSH transport for remote connections (more secure, requires SSH server on target)')]
    [Alias('SSH')]
    [switch]$SshTransport,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Use SSL/TLS for remote connections (encrypts communication)')]
    [Alias('SSL')]
    [switch]$UseSsl,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Port number for remote connection (default: 5985 for HTTP, 5986 for HTTPS, 22 for SSH)')]
  [ValidateScript({ -not $_ -or ($_ -ge 1 -and $_ -le 65535) })]
  [Nullable[int]]$Port,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'SSH key file path for SSH transport authentication')]
    [ValidateNotNullOrEmpty()]
    [ValidateScript({ -not $_ -or (Test-Path $_ -PathType Leaf) })]
    [Alias('SSHKey')]
    [string]$SshKeyPath,
        
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Skip certificate validation for HTTPS connections (not recommended for production)')]
    [Alias('SkipCertCheck')]
    [switch]$SkipCertificateValidation,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Automatically install required DSC resources on remote machine if not available (default: true)')]
  [Alias('AutoInstallResources')]
  [bool]$AutoInstallDscResources = $true,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Skip checking for required DSC resources (useful when resources are known to be available)')]
    [Alias('SkipResources')]
    [switch]$SkipResourceCheck
  )
    
  $invokeArgs = @{ DscPath = $DscPath; Operation = 'Validate'; ComputerName = $ComputerName }
  if ($PSBoundParameters.ContainsKey('Credential')) { $invokeArgs.Credential = $Credential }
  if ($PSBoundParameters.ContainsKey('AutoInstallDsc')) { $invokeArgs.AutoInstallDsc = $AutoInstallDsc }
  if ($PSBoundParameters.ContainsKey('DscInstallerPath')) { $invokeArgs.DscInstallerPath = $DscInstallerPath }
  if ($PSBoundParameters.ContainsKey('PreferredDscVersion')) { $invokeArgs.PreferredDscVersion = $PreferredDscVersion }
  if ($PSBoundParameters.ContainsKey('ForceUpdateCache')) { $invokeArgs.ForceUpdateCache = $ForceUpdateCache }
  if ($PSBoundParameters.ContainsKey('AllowRemoteDownload')) { $invokeArgs.AllowRemoteDownload = $AllowRemoteDownload }
  if ($PSBoundParameters.ContainsKey('SshTransport')) { $invokeArgs.SshTransport = $SshTransport }
  if ($PSBoundParameters.ContainsKey('UseSsl')) { $invokeArgs.UseSsl = $UseSsl }
  if ($PSBoundParameters.ContainsKey('Port')) { $invokeArgs.Port = $Port }
  if ($PSBoundParameters.ContainsKey('SshKeyPath')) { $invokeArgs.SshKeyPath = $SshKeyPath }
  if ($PSBoundParameters.ContainsKey('SkipCertificateValidation')) { $invokeArgs.SkipCertificateValidation = $SkipCertificateValidation }
  if ($PSBoundParameters.ContainsKey('AutoInstallDscResources')) { $invokeArgs.AutoInstallDscResources = $AutoInstallDscResources }
  if ($PSBoundParameters.ContainsKey('SkipResourceCheck')) { $invokeArgs.SkipResourceCheck = $SkipResourceCheck }
  return Invoke-DscHelper @invokeArgs
}

function Export-DscConfiguration {
  <#
    .SYNOPSIS
        Exports current state based on a DSC configuration file.
    .DESCRIPTION
        Wrapper around Invoke-DscHelper for exporting the current state described by the configuration.
        Automatically handles local or remote execution and outputs the DSC JSON result object.
    .PARAMETER DscPath
        Path to the DSC configuration YAML file.
    .PARAMETER ParametersPath
        Optional path to parameters JSON/YAML file.
    .PARAMETER ComputerName
        Target computer name for remote execution.
    .EXAMPLE
        Export-DscConfiguration -DscPath "C:\Configs\WebServer.yaml"
    .EXAMPLE
        Export-DscConfiguration -DscPath "C:\Configs\Cluster.yaml" -ComputerName "SERVER01"
    .OUTPUTS
        [PSCustomObject] DSC JSON output converted to object.
  #>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $true,
      Position = 0,
      HelpMessage = 'Path to the DSC configuration YAML file')]
    [ValidateNotNullOrEmpty()]
    [ValidateScript({ Test-Path $_ -PathType Leaf })]
    [Alias('Path', 'ConfigPath')]
    [string]$DscPath,

    [Parameter(Mandatory = $false,
      HelpMessage = 'Path to parameters JSON/YAML file')]
    [ValidateScript({ -not $_ -or (Test-Path $_ -PathType Leaf) })]
    [Alias('Params', 'ParamFile')]
    [string]$ParametersPath,

    [Parameter(Mandatory = $false,
      HelpMessage = 'Target computer name for remote execution. If not specified or matches current computer, runs locally.')]
    [Alias('Computer', 'Target', 'Server')]
    [string]$ComputerName = $env:COMPUTERNAME,

    [Parameter(Mandatory = $false,
      HelpMessage = 'Suppress verbose output')]
    [Alias('Silent')]
    [switch]$Quiet
  )

  $invokeArgs = @{ 
    DscPath        = $DscPath
    Operation      = 'Export'
    ComputerName   = $ComputerName
    Quiet          = $Quiet
  }
  if ($ParametersPath) { $invokeArgs.ParametersPath = $ParametersPath }
  return Invoke-DscHelper @invokeArgs
}

# Management functions for DSC installer cache

function Get-DscInstallerCache {
  <#
    .SYNOPSIS
        Gets information about cached DSC installers.
    .DESCRIPTION
        Returns information about available DSC installer versions in the module cache.
        Shows cache statistics including disk usage and version management.
    .EXAMPLE
        Get-DscInstallerCache
    .OUTPUTS
        [PSCustomObject] Cache information including available versions and last update check.
    #>
  [CmdletBinding()]
  param()
  
  $cache = Get-InstallerCache
  
  # Calculate cache statistics
  $totalSize = 0
  $fileCount = 0
  $versions = @()
  
  foreach ($version in $cache.AvailableVersions.PSObject.Properties.Name) {
    $installerPath = $cache.AvailableVersions[$version].LocalPath
    if (Test-Path $installerPath) {
      $fileInfo = Get-Item $installerPath
      $totalSize += $fileInfo.Length
      $fileCount++
      $versions += [PSCustomObject]@{
        Version     = $version
        Size        = $fileInfo.Length
        SizeMB      = [math]::Round($fileInfo.Length / 1MB, 2)
        PublishedAt = $cache.AvailableVersions[$version].PublishedAt
        IsCurrent   = ($version -eq $cache.CurrentVersion)
      }
    }
    else {
      # File is missing from disk but still in cache
      $versions += [PSCustomObject]@{
        Version     = $version
        Size        = 0
        SizeMB      = 0
        PublishedAt = $cache.AvailableVersions[$version].PublishedAt
        IsCurrent   = ($version -eq $cache.CurrentVersion)
        Missing     = $true
      }
    }
  }
  
  # Add statistics to the result
  $cache | Add-Member -MemberType NoteProperty -Name "Statistics" -Value @{
    TotalFiles  = $fileCount
    TotalSize   = $totalSize
    TotalSizeMB = [math]::Round($totalSize / 1MB, 2)
    MaxVersions = $script:ModuleConfig.MaxCachedVersions
    Versions    = $versions | Sort-Object Version -Descending
  } -Force
  
  return $cache
}

function Update-DscInstallerCache {
  <#
    .SYNOPSIS
        Updates the DSC installer cache.
    .DESCRIPTION
        Checks for new DSC versions and downloads them to the module cache.
        This enables offline installation on remote machines.
        By default, keeps only the 3 most recent versions to save disk space.
    .PARAMETER Force
        Force update even if cache is recent.
    .PARAMETER Quiet
        Suppress verbose output.
    .PARAMETER MaxVersions
        Maximum number of DSC versions to keep cached (default: 3).
        Use 0 to keep all versions.
    .EXAMPLE
        Update-DscInstallerCache
    .EXAMPLE
        Update-DscInstallerCache -Force
    .EXAMPLE
        Update-DscInstallerCache -MaxVersions 5
    .EXAMPLE
        Update-DscInstallerCache -MaxVersions 0  # Keep all versions
    #>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Force update even if cache is recent')]
    [switch]$Force,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Suppress verbose output')]
    [switch]$Quiet,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Maximum number of DSC versions to keep cached (default: 3, use 0 for unlimited)')]
    [ValidateRange(0, [int]::MaxValue)]
    [int]$MaxVersions = $script:ModuleConfig.MaxCachedVersions
  )
  
  Update-DscInstallerCacheInternal -Force:$Force -Quiet:$Quiet -MaxVersions $MaxVersions
}

function Remove-DscInstallerCache {
  <#
    .SYNOPSIS
        Removes cached DSC installers.
    .DESCRIPTION
        Removes all cached DSC installer files and cache metadata.
    .PARAMETER Version
        Specific version to remove. If not specified, removes all versions.
    .EXAMPLE
        Remove-DscInstallerCache
    .EXAMPLE
        Remove-DscInstallerCache -Version "1.0.0"
    #>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Specific version to remove')]
    [string]$Version
  )
  
  $cache = Get-InstallerCache
  
  if ($Version) {
    if ($cache.AvailableVersions.PSObject.Properties.Name -contains $Version) {
      $installerPath = $cache.AvailableVersions[$Version].LocalPath
      if (Test-Path $installerPath) {
        Remove-Item -Path $installerPath -Force
        Write-Host "Removed DSC installer version $Version" -ForegroundColor Green
      }
      
      $cache.AvailableVersions.PSObject.Properties.Remove($Version)
      Update-InstallerCache -CacheData $cache
    }
    else {
      Write-Warning "DSC installer version $Version not found in cache"
    }
  }
  else {
    # Remove all cached installers
    foreach ($version in $cache.AvailableVersions.PSObject.Properties.Name) {
      $installerPath = $cache.AvailableVersions[$version].LocalPath
      if (Test-Path $installerPath) {
        Remove-Item -Path $installerPath -Force
      }
    }
    
    # Reset cache
    @{
      LastUpdateCheck   = $null
      AvailableVersions = @{}
      CurrentVersion    = $null
    } | ConvertTo-Json | Set-Content -Path $script:ModuleConfig.InstallerCacheFile
    
    Write-Host "Removed all cached DSC installers" -ForegroundColor Green
  }
}

# Repair incomplete DSC installation
function Repair-DscInstallation {
  <#
    .SYNOPSIS
        Repairs incomplete DSC v3 installations by ensuring all necessary files are present.
    .DESCRIPTION
        Detects if DSC v3 is installed but missing configuration files, and repairs the installation
        by copying all necessary files from a cached installer or downloading a fresh copy.
    .PARAMETER ComputerName
        Target computer name for remote repair. Defaults to local machine.
    .PARAMETER Credential
        Credential for remote connection (optional).
    .PARAMETER Quiet
        Suppress verbose output.
    .PARAMETER Force
        Force repair even if DSC appears to be working correctly.
    .EXAMPLE
        Repair-DscInstallation
    .EXAMPLE
        Repair-DscInstallation -ComputerName "SERVER01" -Credential $cred
    .EXAMPLE
        Repair-DscInstallation -Force
    #>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Target computer name for remote repair. If not specified or matches current computer, repairs locally.')]
    [ValidateNotNullOrEmpty()]
    [Alias('Computer', 'Target', 'Server')]
    [string]$ComputerName = $env:COMPUTERNAME,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Credential for remote connection (only needed for remote repair)')]
    [Alias('Cred')]
    [PSCredential]$Credential,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Suppress verbose output')]
    [switch]$Quiet,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Force repair even if DSC appears to be working correctly')]
    [switch]$Force
  )
  
  try {
    $isRemote = $ComputerName -ne $env:COMPUTERNAME
    
    if ($isRemote) {
      # Remote repair
      if (-not $Quiet) {
        Write-Host "Checking DSC installation on remote machine: $ComputerName" -ForegroundColor Yellow
      }
      
      # Create remote session
      $session = New-SecureRemoteSession -TargetComputer $ComputerName -Credential $Credential -Quiet:$Quiet
      
      try {
        $repairResult = Invoke-Command -Session $session -ScriptBlock {
          param($Force, $Quiet)
          
          # Check if DSC executable exists
          $dscExePath = $null
          try {
            $dscExePath = (Get-Command 'dsc.exe' -ErrorAction Stop).Source
          }
          catch {
            Write-Host "DSC executable not found in PATH" -ForegroundColor Yellow
            return @{ NeedsRepair = $false; Reason = "DSC not installed" }
          }
          
          if (-not $dscExePath) {
            return @{ NeedsRepair = $false; Reason = "DSC not installed" }
          }
          
          $installDir = Split-Path $dscExePath -Parent
          
          # Check if this is a complete installation by looking for configuration files
          $configFiles = @(
            "settings.json",
            "dsc.exe.config",
            "*.dll",
            "*.json"
          )
          
          $missingFiles = @()
          foreach ($pattern in $configFiles) {
            $files = Get-ChildItem -Path $installDir -Name $pattern -ErrorAction SilentlyContinue
            if (-not $files) {
              $missingFiles += $pattern
            }
          }
          
          # Also check if there are very few files (indicating incomplete installation)
          $totalFiles = (Get-ChildItem -Path $installDir -File | Measure-Object).Count
          
          if ($Force -or $missingFiles.Count -gt 0 -or $totalFiles -lt 3) {
            return @{ 
              NeedsRepair  = $true; 
              InstallDir   = $installDir; 
              MissingFiles = $missingFiles; 
              TotalFiles   = $totalFiles;
              Reason       = "Incomplete installation detected"
            }
          }
          else {
            return @{ NeedsRepair = $false; Reason = "Installation appears complete" }
          }
        } -ArgumentList $Force, $Quiet
        
        if ($repairResult.NeedsRepair) {
          if (-not $Quiet) {
            Write-Host "Incomplete DSC installation detected on $ComputerName" -ForegroundColor Yellow
            Write-Host "Install directory: $($repairResult.InstallDir)" -ForegroundColor Cyan
            Write-Host "Missing files: $($repairResult.MissingFiles -join ', ')" -ForegroundColor Cyan
            Write-Host "Total files: $($repairResult.TotalFiles)" -ForegroundColor Cyan
            Write-Host "Repairing installation..." -ForegroundColor Yellow
          }
          
          # Get cached installer for repair
          $installerPath = Get-DscInstallerPath -Quiet:$Quiet
          if (-not $installerPath) {
            throw "No cached DSC installer found. Run Update-DscInstallerCache first to download an installer."
          }
          
          # Copy installer to remote machine and repair
          $remoteTempDir = "C:\Temp\DtbDscHelper"
          Invoke-Command -Session $session -ScriptBlock {
            New-Item -Path $using:remoteTempDir -ItemType Directory -Force | Out-Null
          }
          
          $installerFileName = Split-Path $installerPath -Leaf
          $remoteInstallerPath = Join-Path $remoteTempDir $installerFileName
          Copy-Item -Path $installerPath -Destination $remoteInstallerPath -ToSession $session -Force
          
          # Repair the installation
          $repairSuccess = Invoke-Command -Session $session -ScriptBlock {
            param($RemoteInstallerPath, $InstallDir, $Quiet)
            
            try {
              $fileExtension = [System.IO.Path]::GetExtension($RemoteInstallerPath).ToLower()
              
              if ($fileExtension -eq ".zip") {
                # Extract and repair from ZIP
                if (-not $Quiet) {
                  Write-Host "Extracting DSC files for repair..." -ForegroundColor Cyan
                }
                
                $extractPath = Join-Path $env:TEMP "DscRepair"
                Expand-Archive -Path $RemoteInstallerPath -DestinationPath $extractPath -Force
                
                # Find dsc.exe in extracted files
                $dscExe = Get-ChildItem -Path $extractPath -Recurse -Name "dsc.exe" | Select-Object -First 1
                if ($dscExe) {
                  $dscPath = Join-Path $extractPath $dscExe
                  $dscDir = Split-Path $dscPath -Parent
                  
                  # Backup existing files
                  $backupDir = "$InstallDir.backup.$(Get-Date -Format 'yyyyMMddHHmmss')"
                  if (Test-Path $InstallDir) {
                    Copy-Item -Path $InstallDir -Destination $backupDir -Recurse -Force
                    if (-not $Quiet) {
                      Write-Host "Backed up existing installation to: $backupDir" -ForegroundColor Cyan
                    }
                  }
                  
                  # Copy all files from extracted directory
                  if (-not $Quiet) {
                    Write-Host "Copying all DSC files to repair installation..." -ForegroundColor Cyan
                  }
                  Copy-Item -Path "$dscDir\*" -Destination $InstallDir -Recurse -Force
                  
                  # Cleanup
                  Remove-Item -Path $extractPath -Recurse -Force -ErrorAction SilentlyContinue
                  
                  return $true
                }
                else {
                  Write-Host "dsc.exe not found in installer" -ForegroundColor Yellow
                  return $false
                }
              }
              else {
                Write-Host "Unsupported installer format: $fileExtension" -ForegroundColor Yellow
                return $false
              }
            }
            catch {
              Write-Host "Repair failed: $($_.Exception.Message)" -ForegroundColor Yellow
              return $false
            }
          } -ArgumentList $remoteInstallerPath, $repairResult.InstallDir, $Quiet
          
          if ($repairSuccess) {
            if (-not $Quiet) {
              Write-Host "✓ DSC installation repaired successfully on $ComputerName" -ForegroundColor Green
            }
            return $true
          }
          else {
            throw "Failed to repair DSC installation on $ComputerName"
          }
        }
        else {
          if (-not $Quiet) {
            Write-Host "✓ DSC installation on $ComputerName appears complete: $($repairResult.Reason)" -ForegroundColor Green
          }
          return $true
        }
      }
      finally {
        Remove-PSSession -Session $session -ErrorAction SilentlyContinue
      }
    }
    else {
      # Local repair
      if (-not $Quiet) {
        Write-Host "Checking local DSC installation..." -ForegroundColor Yellow
      }
      
      # Check if DSC executable exists
      $dscExePath = $null
      try {
        $dscExePath = (Get-Command 'dsc.exe' -ErrorAction Stop).Source
      }
      catch {
        if (-not $Quiet) {
          Write-Host "DSC executable not found in PATH" -ForegroundColor Yellow
        }
        return $false
      }
      
      if (-not $dscExePath) {
        return $false
      }
      
      $installDir = Split-Path $dscExePath -Parent
      
      # Check if this is a complete installation by looking for configuration files
      $configFiles = @(
        "settings.json",
        "dsc.exe.config",
        "*.dll",
        "*.json"
      )
      
      $missingFiles = @()
      foreach ($pattern in $configFiles) {
        $files = Get-ChildItem -Path $installDir -Name $pattern -ErrorAction SilentlyContinue
        if (-not $files) {
          $missingFiles += $pattern
        }
      }
      
      # Also check if there are very few files (indicating incomplete installation)
      $totalFiles = (Get-ChildItem -Path $installDir -File | Measure-Object).Count
      
      if ($Force -or $missingFiles.Count -gt 0 -or $totalFiles -lt 3) {
        if (-not $Quiet) {
          Write-Host "Incomplete DSC installation detected locally" -ForegroundColor Yellow
          Write-Host "Install directory: $installDir" -ForegroundColor Cyan
          Write-Host "Missing files: $($missingFiles -join ', ')" -ForegroundColor Cyan
          Write-Host "Total files: $totalFiles" -ForegroundColor Cyan
          Write-Host "Repairing installation..." -ForegroundColor Yellow
        }
        
        # Get cached installer for repair
        $installerPath = Get-DscInstallerPath -Quiet:$Quiet
        if (-not $installerPath) {
          throw "No cached DSC installer found. Run Update-DscInstallerCache first to download an installer."
        }
        
        try {
          $fileExtension = [System.IO.Path]::GetExtension($installerPath).ToLower()
          
          if ($fileExtension -eq ".zip") {
            # Extract and repair from ZIP
            if (-not $Quiet) {
              Write-Host "Extracting DSC files for repair..." -ForegroundColor Cyan
            }
            
            $extractPath = Join-Path $env:TEMP "DscRepair"
            Expand-Archive -Path $installerPath -DestinationPath $extractPath -Force
            
            # Find dsc.exe in extracted files
            $dscExe = Get-ChildItem -Path $extractPath -Recurse -Name "dsc.exe" | Select-Object -First 1
            if ($dscExe) {
              $dscPath = Join-Path $extractPath $dscExe
              $dscDir = Split-Path $dscPath -Parent
              
              # Backup existing files
              $backupDir = "$installDir.backup.$(Get-Date -Format 'yyyyMMddHHmmss')"
              if (Test-Path $installDir) {
                Copy-Item -Path $installDir -Destination $backupDir -Recurse -Force
                if (-not $Quiet) {
                  Write-Host "Backed up existing installation to: $backupDir" -ForegroundColor Cyan
                }
              }
              
              # Copy all files from extracted directory
              if (-not $Quiet) {
                Write-Host "Copying all DSC files to repair installation..." -ForegroundColor Cyan
              }
              Copy-Item -Path "$dscDir\*" -Destination $installDir -Recurse -Force
              
              # Cleanup
              Remove-Item -Path $extractPath -Recurse -Force -ErrorAction SilentlyContinue
              
              if (-not $Quiet) {
                Write-Host "✓ Local DSC installation repaired successfully" -ForegroundColor Green
              }
              return $true
            }
            else {
              throw "dsc.exe not found in installer"
            }
          }
          else {
            throw "Unsupported installer format: $fileExtension"
          }
        }
        catch {
          Write-Error "Local DSC repair failed: $($_.Exception.Message)"
          throw
        }
      }
      else {
        if (-not $Quiet) {
          Write-Host "✓ Local DSC installation appears complete" -ForegroundColor Green
        }
        return $true
      }
    }
    catch {
      Write-Error "Local DSC repair failed: $($_.Exception.Message)"
      throw
    }
  
  }
  catch {
    Write-Error "DSC repair failed: $($_.Exception.Message)"
    throw
  }
}

# Management functions for DSC resource cache

function Get-DscResourceCache {
  <#
    .SYNOPSIS
        Gets information about cached DSC resources.
    .DESCRIPTION
        Returns information about available DSC resource versions in the module cache.
        Shows cache statistics including disk usage and resource management.
    .EXAMPLE
        Get-DscResourceCache
    .OUTPUTS
        [PSCustomObject] Cache information including available resources and last update check.
    #>
  [CmdletBinding()]
  param()
  
  $cache = Get-ResourceCache
  
  # Calculate cache statistics
  $totalSize = 0
  $fileCount = 0
  $resources = @()
  
  foreach ($resource in $cache.AvailableResources.PSObject.Properties.Name) {
    $resourcePath = $cache.AvailableResources[$resource].LocalPath
    if (Test-Path $resourcePath) {
      $fileInfo = Get-Item $resourcePath
      $totalSize += $fileInfo.Length
      $fileCount++
      $resources += [PSCustomObject]@{
        Resource     = $resource
        Size         = $fileInfo.Length
        SizeMB       = [math]::Round($fileInfo.Length / 1MB, 2)
        DownloadedAt = $cache.AvailableResources[$resource].DownloadedAt
        Source       = $cache.AvailableResources[$resource].Source
      }
    }
    else {
      # File is missing from disk but still in cache
      $resources += [PSCustomObject]@{
        Resource     = $resource
        Size         = 0
        SizeMB       = 0
        DownloadedAt = $cache.AvailableResources[$resource].DownloadedAt
        Source       = $cache.AvailableResources[$resource].Source
        Missing      = $true
      }
    }
  }
  
  # Add statistics to the result
  $cache | Add-Member -MemberType NoteProperty -Name "Statistics" -Value @{
    TotalFiles   = $fileCount
    TotalSize    = $totalSize
    TotalSizeMB  = [math]::Round($totalSize / 1MB, 2)
    MaxResources = $script:ModuleConfig.MaxCachedResources
    Resources    = $resources | Sort-Object Resource
  } -Force
  
  return $cache
}

function Update-DscResourceCache {
  <#
    .SYNOPSIS
        Updates the DSC resource cache.
    .DESCRIPTION
        Discovers and downloads DSC resources from various sources to the module cache.
        This enables offline installation of resources on remote machines.
        By default, keeps only the 50 most recent resources to save disk space.
    .PARAMETER Force
        Force update even if cache is recent.
    .PARAMETER Quiet
        Suppress verbose output.
    .PARAMETER MaxResources
        Maximum number of DSC resources to keep cached (default: 50).
        Use 0 to keep all resources.
    .PARAMETER SpecificResource
        Download a specific resource type (for internal use).
    .EXAMPLE
        Update-DscResourceCache
    .EXAMPLE
        Update-DscResourceCache -Force
    .EXAMPLE
        Update-DscResourceCache -MaxResources 100
    .EXAMPLE
        Update-DscResourceCache -MaxResources 0  # Keep all resources
    #>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Force update even if cache is recent')]
    [switch]$Force,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Suppress verbose output')]
    [switch]$Quiet,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Maximum number of DSC resources to keep cached (default: 50, use 0 for unlimited)')]
    [ValidateRange(0, [int]::MaxValue)]
    [int]$MaxResources = $script:ModuleConfig.MaxCachedResources,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Download a specific resource type (for internal use)')]
    [string]$SpecificResource
  )
  
  Update-DscResourceCacheInternal -Force:$Force -Quiet:$Quiet -MaxResources $MaxResources -SpecificResource $SpecificResource
}

function Remove-DscResourceCache {
  <#
    .SYNOPSIS
        Removes cached DSC resources.
    .DESCRIPTION
        Removes all cached DSC resource files and cache metadata.
    .PARAMETER ResourceType
        Specific resource type to remove. If not specified, removes all resources.
    .EXAMPLE
        Remove-DscResourceCache
    .EXAMPLE
        Remove-DscResourceCache -ResourceType "Microsoft.Windows/Registry"
    #>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Specific resource type to remove')]
    [string]$ResourceType
  )
  
  $cache = Get-ResourceCache
  
  if ($ResourceType) {
    $matchingResources = $cache.AvailableResources.PSObject.Properties.Name | Where-Object { $_ -like "$ResourceType*" }
    
    foreach ($resource in $matchingResources) {
      $resourcePath = $cache.AvailableResources.$resource.LocalPath
      if (Test-Path $resourcePath) {
        Remove-Item -Path $resourcePath -Force
        Write-Host "Removed DSC resource: $resource" -ForegroundColor Green
      }
      
      # Remove from cache
      $cache.AvailableResources.PSObject.Properties.Remove($resource)
    }
    
    Update-ResourceCache -CacheData $cache
  }
  else {
    # Remove all cached resources
    foreach ($resource in $cache.AvailableResources.PSObject.Properties.Name) {
      $resourcePath = $cache.AvailableResources[$resource].LocalPath
      if (Test-Path $resourcePath) {
        Remove-Item -Path $resourcePath -Force
      }
    }
    
    # Reset cache
    @{
      LastUpdateCheck    = $null
      AvailableResources = @{}
      ResourceMetadata   = @{}
      CurrentVersions    = @{}
    } | ConvertTo-Json | Set-Content -Path $script:ModuleConfig.ResourceCacheFile
    
    Write-Host "Removed all cached DSC resources" -ForegroundColor Green
  }
}

function Install-DscResourceOffline {
  <#
    .SYNOPSIS
        Installs a specific DSC resource from the local cache.
    .DESCRIPTION
        Installs a DSC resource from the local cache to the target machine.
        This function is useful for installing specific resources without updating the entire cache.
    .PARAMETER ResourceType
        The DSC resource type to install.
    .PARAMETER ComputerName
        Target computer name for remote installation. Defaults to local machine.
    .PARAMETER Credential
        Credential for remote connection (optional).
    .PARAMETER PreferredVersion
        Preferred version of the resource to install.
    .PARAMETER Quiet
        Suppress verbose output.
    .EXAMPLE
        Install-DscResourceOffline -ResourceType "Microsoft.Windows/Registry"
    .EXAMPLE
        Install-DscResourceOffline -ResourceType "Microsoft.Windows/Registry" -ComputerName "SERVER01"
    .EXAMPLE
        Install-DscResourceOffline -ResourceType "Microsoft.Windows/Registry" -PreferredVersion "0.1.0"
    #>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $true, 
      Position = 0,
      HelpMessage = 'The DSC resource type to install')]
    [ValidateNotNullOrEmpty()]
    [string]$ResourceType,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Target computer name for remote installation. If not specified or matches current computer, installs locally.')]
    [ValidateNotNullOrEmpty()]
    [Alias('Computer', 'Target', 'Server')]
    [string]$ComputerName = $env:COMPUTERNAME,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Credential for remote connection (only needed for remote installation)')]
    [Alias('Cred')]
    [PSCredential]$Credential,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Preferred version of the resource to install')]
    [ValidateNotNullOrEmpty()]
    [Alias('Version')]
    [string]$PreferredVersion,
    
    [Parameter(Mandatory = $false, 
      HelpMessage = 'Suppress verbose output')]
    [switch]$Quiet
  )
  
  try {
    # Check if resource is available in cache, if not, try to download it automatically
    $localResourcePath = Get-DscResourcePath -ResourceType $ResourceType -PreferredVersion $PreferredVersion -Quiet:$Quiet
    if (-not $localResourcePath) {
      if (-not $Quiet) {
        Write-Host "Resource $ResourceType not found in cache. Attempting to download automatically..." -ForegroundColor Yellow
      }
      
      # Try to download the specific resource
      $downloadResult = Update-DscResourceCacheInternal -Force -Quiet:$Quiet -SpecificResource $ResourceType
      if ($downloadResult) {
        # Try to get the resource path again
        $localResourcePath = Get-DscResourcePath -ResourceType $ResourceType -PreferredVersion $PreferredVersion -Quiet:$Quiet
      }
      
      if (-not $localResourcePath) {
        throw "Resource $ResourceType not available in cache and could not be downloaded automatically. Run Update-DscResourceCache to refresh the cache or check if the resource is available."
      }
    }
    
    $isRemote = $ComputerName -ne $env:COMPUTERNAME
    
    if ($isRemote) {
      # Remote installation
      if (-not $Quiet) {
        Write-Host "Installing DSC resource $ResourceType on remote machine: $ComputerName" -ForegroundColor Yellow
      }
      
      # Create remote session
      $session = New-SecureRemoteSession -TargetComputer $ComputerName -Credential $Credential -Quiet:$Quiet
      
      try {
        # Get local resource package (already verified above)
        
        # Copy resource package to remote machine
        $remoteTempDir = "C:\Temp\DtbDscHelper"
        Invoke-Command -Session $session -ScriptBlock {
          New-Item -Path $using:remoteTempDir -ItemType Directory -Force | Out-Null
        }
        
        $resourceFileName = Split-Path $localResourcePath -Leaf
        $remoteResourcePath = Join-Path $remoteTempDir $resourceFileName
        Copy-Item -Path $localResourcePath -Destination $remoteResourcePath -ToSession $session -Force
        
        # Install the resource
        $installResult = Invoke-Command -Session $session -ScriptBlock {
          param($ResourceType, $RemoteResourcePath)
          
          try {
            # Initialize DSC environment for remote session
            $env:DSC_TRACE = "0"  # Disable tracing to avoid the error
            $env:DSC_LOG_LEVEL = "error"  # Only show errors
            
            Write-Host "Installing DSC resource $ResourceType from local package..." -ForegroundColor Cyan
            
            # Extract resource package
            $tempDir = Join-Path $env:TEMP "DscResourceInstall"
            New-Item -Path $tempDir -ItemType Directory -Force | Out-Null
            
            try {
              # Extract the resource package
              Expand-Archive -Path $RemoteResourcePath -DestinationPath $tempDir -Force
              
              # Determine DSC installation directory
              $dscExePath = (Get-Command 'dsc.exe' -ErrorAction SilentlyContinue).Source
              if ($dscExePath) {
                $dscDir = Split-Path $dscExePath -Parent
              }
              else {
                # Fallback to default installation path
                $dscDir = "C:\Program Files\Microsoft DSC"
              }
              
              # Copy resource files to DSC directory
              $resourceFiles = Get-ChildItem -Path $tempDir -Recurse -File
              foreach ($file in $resourceFiles) {
                $relativePath = $file.FullName.Substring($tempDir.Length + 1)
                $targetPath = Join-Path $dscDir $relativePath
                $targetDir = Split-Path $targetPath -Parent
                
                if (-not (Test-Path $targetDir)) {
                  New-Item -Path $targetDir -ItemType Directory -Force | Out-Null
                }
                
                Copy-Item -Path $file.FullName -Destination $targetPath -Force
              }
              
              Write-Host "Successfully installed resource: $ResourceType" -ForegroundColor Green
              return $true
              
            }
            finally {
              # Cleanup temp directory
              if (Test-Path $tempDir) {
                Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
              }
            }
            
          }
          catch {
            Write-Host "Exception installing resource $ResourceType`: $($_.Exception.Message)" -ForegroundColor Yellow
            return $false
          }
        } -ArgumentList $ResourceType, $remoteResourcePath
        
        if ($installResult) {
          if (-not $Quiet) {
            Write-Host "✓ DSC resource $ResourceType installed successfully on $ComputerName" -ForegroundColor Green
          }
          return $true
        }
        else {
          throw "Failed to install DSC resource $ResourceType on $ComputerName"
        }
      }
      finally {
        Remove-PSSession -Session $session -ErrorAction SilentlyContinue
      }
    }
    else {
      # Local installation
      if (-not $Quiet) {
        Write-Host "Installing DSC resource $ResourceType locally..." -ForegroundColor Yellow
      }
      
      # Install locally (resource path already verified above)
      $installResult = & {
        try {
          # Initialize DSC environment
          $env:DSC_TRACE = "0"  # Disable tracing to avoid the error
          $env:DSC_LOG_LEVEL = "error"  # Only show errors
          
          Write-Host "Installing DSC resource $ResourceType from local package..." -ForegroundColor Cyan
          
          # Extract resource package
          $tempDir = Join-Path $env:TEMP "DscResourceInstall"
          New-Item -Path $tempDir -ItemType Directory -Force | Out-Null
          
          try {
            # Extract the resource package
            Expand-Archive -Path $localResourcePath -DestinationPath $tempDir -Force
            
            # Determine DSC installation directory
            $dscExePath = (Get-Command 'dsc.exe' -ErrorAction SilentlyContinue).Source
            if ($dscExePath) {
              $dscDir = Split-Path $dscExePath -Parent
            }
            else {
              # Fallback to default installation path
              $dscDir = "C:\Program Files\Microsoft DSC"
            }
            
            # Copy resource files to DSC directory
            $resourceFiles = Get-ChildItem -Path $tempDir -Recurse -File
            foreach ($file in $resourceFiles) {
              $relativePath = $file.FullName.Substring($tempDir.Length + 1)
              $targetPath = Join-Path $dscDir $relativePath
              $targetDir = Split-Path $targetPath -Parent
              
              if (-not (Test-Path $targetDir)) {
                New-Item -Path $targetDir -ItemType Directory -Force | Out-Null
              }
              
              Copy-Item -Path $file.FullName -Destination $targetPath -Force
            }
            
            Write-Host "Successfully installed resource: $ResourceType" -ForegroundColor Green
            return $true
            
          }
          finally {
            # Cleanup temp directory
            if (Test-Path $tempDir) {
              Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
            }
          }
          
        }
        catch {
          Write-Host "Exception installing resource $ResourceType`: $($_.Exception.Message)" -ForegroundColor Yellow
          return $false
        }
      }
      
      if ($installResult) {
        if (-not $Quiet) {
          Write-Host "✓ Local DSC resource $ResourceType installed successfully" -ForegroundColor Green
        }
        return $true
      }
      else {
        throw "Failed to install DSC resource $ResourceType locally"
      }
    }
  }
  catch {
    Write-Error "DSC resource installation failed: $($_.Exception.Message)"
    throw
  }
}

# Export the functions
Export-ModuleMember -Function 'Invoke-DscHelper', 'Validate-DscConfiguration', 'Set-DscConfiguration', 'Test-DscConfiguration', 'Export-DscConfiguration', 'Get-DscInstallerCache', 'Update-DscInstallerCache', 'Remove-DscInstallerCache', 'Get-DscInstallerPath', 'Get-Head', 'Get-Tail', 'New-SecureRemoteSession', 'Repair-DscInstallation', 'Get-DscResourceCache', 'Update-DscResourceCache', 'Remove-DscResourceCache', 'Get-DscResourcePath', 'Install-DscResourceOffline', 'Ensure-DscResourcesAvailable', 'Get-MappedResourceInfo'

# Initialize caches on module import
try {
  Write-Host "Initializing DSC module caches..." -ForegroundColor Cyan
    
  # Initialize installer cache
  Initialize-InstallerCache
    
  # Initialize resource cache  
  Initialize-ResourceCache
    
  # Try to update installer cache if needed (but don't fail if it doesn't work)
  try {
    if (Test-UpdateCheckNeeded) {
      Write-Host "Updating DSC installer cache..." -ForegroundColor Yellow
      Update-DscInstallerCacheInternal -Quiet
    }
  }
  catch {
    Write-Warning "Failed to update DSC installer cache on import: $($_.Exception.Message)"
    Write-Warning "You can manually run Update-DscInstallerCache to download installers."
  }
    
  Write-Host "DSC module initialized successfully." -ForegroundColor Green
}
catch {
  Write-Warning "Failed to initialize DSC module caches: $($_.Exception.Message)"
  Write-Warning "Some DSC operations may not work correctly. Please check the module configuration."
} 
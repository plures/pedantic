# This meta-module re-exports the public surface from Dtb.DSC to the new name StateSmith.DSC
# It allows users to `Import-Module StateSmith.DSC` while we keep the implementation in Dtb.DSC.psm1.
# Later, we can migrate implementations into this module or continue re-exporting.

# Ensure the legacy module is loaded from the same directory if available
$moduleRoot = Split-Path -Parent $PSCommandPath
$legacyModulePath = Join-Path $moduleRoot 'Dtb.DSC.psm1'
if (Test-Path $legacyModulePath) {
    Import-Module $legacyModulePath -Force -Global
}
else {
    Write-Verbose "Legacy module Dtb.DSC.psm1 not found next to StateSmith.DSC.psm1. Ensure it is available in PSModulePath."
    Import-Module Dtb.DSC -ErrorAction SilentlyContinue
}

# Re-export commands from Dtb.DSC
$legacyModule = Get-Module Dtb.DSC -ListAvailable | Select-Object -First 1
if (-not $legacyModule) {
    $legacyModule = Get-Module Dtb.DSC
}
if ($legacyModule) {
    $public = (Get-Command -Module $legacyModule.Name | Where-Object { $_.CommandType -in 'Function','Cmdlet','Alias' })
    foreach ($cmd in $public) {
        if ($cmd.CommandType -eq 'Alias') { continue }
        $name = $cmd.Name
        Set-Alias -Name $name -Value $name -Scope Global -Option AllScope -Force 2>$null
        Export-ModuleMember -Function $name -ErrorAction SilentlyContinue
    }
    # Export aliases too
    $aliases = Get-Alias | Where-Object { $_.ReferencedCommand.ModuleName -eq $legacyModule.Name }
    foreach ($a in $aliases) {
        Export-ModuleMember -Alias $a.Name -ErrorAction SilentlyContinue
    }
}
else {
    Write-Warning 'StateSmith.DSC: Could not locate Dtb.DSC. Commands may be unavailable until Dtb.DSC is installed.'
}

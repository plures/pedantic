@{
  RootModule = 'StateSmith.DSC.psm1'
  ModuleVersion = '0.9.0'
  GUID = '2b6a3c27-1a4a-4d3f-9c9f-9b8b7d9d1234'
  Author = 'StateSmith Project'
  CompanyName = 'StateSmith'
  Copyright = '(c) StateSmith. All rights reserved.'
  Description = 'Meta-module for StateSmith branding. Re-exports public commands from Dtb.DSC to provide the new module name without breaking changes.'
  PowerShellVersion = '7.2'
  CompatiblePSEditions = @('Core')
  FunctionsToExport = '*'
  CmdletsToExport = @()
  VariablesToExport = '*'
  AliasesToExport = '*'
  NestedModules = @('Dtb.DSC.psm1')
  PrivateData = @{ PSData = @{ Tags = @('DSC','StateSmith','Meta','Alias') } }
}

# Project Roadmap: Clean, Stable Release

This roadmap prioritizes getting this repository to a clean, stable 1.0.0 release. It reflects the current codebase state and outlines pragmatic steps, quality gates, and release criteria.

Brand note: The project name will be rebranded to "StateSmith". Module names may remain `Dtb.DSC` initially to avoid breaking changes; see `REBRANDING.md`.

## Current state summary (as of 2025-09-22)

- Scope: PowerShell modules and utilities around DSC v3
  - `Dtb.DSC.psm1` – core helper module (installer/resource caching, resource mapping, discovery, download)
  - `DSCHelper.ps1` – script wrapper to execute DSC operations (Set/Test/Validate/Export) with better UX
  - Simple DSL converters: `Simple.DSC.Basic.psm1` and `Simple.DSC.psm1`
  - A custom resource pack: `SimpleDSC.psd1` with `Resources/SimpleDSC.PackageInstaller`
- Documentation: `README.md` (Dtb.DSC helper), `Simple-DSC-README.md` (Simple DSL)
- Samples/configs: multiple `.yaml` DSC examples
- Observed gaps and risks
  - Manifest exports vs implementation mismatch: `Dtb.DSC.psd1` exports functions like `Invoke-DscHelper`, `Validate-DscConfiguration`, `Set-DscConfiguration`, `Test-DscConfiguration`, `New-SecureRemoteSession`, `Repair-DscInstallation` that are not found in `Dtb.DSC.psm1` (names or casing differ or missing).
  - The wrapper functionality exists in `DSCHelper.ps1` but not as cmdlets inside `Dtb.DSC.psm1`.
  - Duplicated/overlapping Simple DSL implementations (`Simple.DSC.Basic.psm1` vs `Simple.DSC.psm1`), with basic YAML parsers not suitable for production.
  - No test suite present (Pester), no static analysis setup (PSScriptAnalyzer), no CI.
  - Manifest metadata contains placeholders (CompanyName = "Microsoft"), unclear license, project/site URIs empty.
  - Network calls to GitHub and PowerShell Gallery without resilience (retries, offline fallback validation) beyond caching logic.

## Goals and release strategy

- Short term (stabilize): deliver a cohesive helper module with a clear, supported public API, complete docs, and test coverage; package as a proper PowerShell module.
- Medium term (UX): unify the DSL story or clearly flag it as experimental; improve offline and remote scenarios; add CI/CD and release automation.
- Long term: rebrand (StateSmith), deprecate shims gracefully, expand cross-platform manager support (apt/yum/brew), and grow docs.

## Milestones and priorities

1) Public API freeze and module hygiene (Priority: P0)

- Decide and document the supported public commands. Recommended surface in `Dtb.DSC`:
  - Core ops: `Set-DscConfiguration`, `Test-DscConfiguration`, `Validate-DscConfiguration`, `Export-DscConfiguration`
  - Caching: `Update-DscInstallerCache`, `Get-DscInstallerPath`, `Update-DscResourceCache`, `Get-DscResourcePath`, `Ensure-DscResourcesAvailable`
  - Utilities: `Get-Head`/`Get-Tail`

- Actions
  - Implement missing exported functions in `Dtb.DSC.psm1` by moving/refactoring logic from `DSCHelper.ps1` into public cmdlets.
  - Or, if keeping the script, update `Dtb.DSC.psd1` `FunctionsToExport` to match actual functions in `Dtb.DSC.psm1` and add a thin wrapper cmdlet that shells to `DSCHelper`.
  - Remove/rename any misleading exports and align names/casing (`Validate-DscConfiguration` vs `validate-DscConfiguration`).
  - Fill gaps like `Ensure-DscResourcesAvailable` (currently only `Test-DscResourceAvailability` exists) or rename consistently.

Acceptance criteria

- Importing the module on PS 7.2+ succeeds without warnings.
- `Get-Command -Module Dtb.DSC` lists only the intended public functions; each has comment-based help.
- Basic end-to-end flow validated locally: Validate → Test → Set on example YAML.

1) Tests, linting, and quality gates (P0)

- Add Pester unit tests for each public cmdlet (parameter binding, happy path, error path) and a couple of integration tests using a dry-run (`--whatif`) where possible.
- Add PSScriptAnalyzer with a `.psd1` settings file; fix or suppress with justification.
- Gate PRs on: PSScriptAnalyzer, Pester, basic import smoke tests.

Acceptance criteria

- CI runs PSScriptAnalyzer and Pester on Windows-latest with PS 7.2/7.4.
- 70%+ function-level coverage on public surface; green CI required to merge.

1) Packaging, versioning, and metadata (P0)

- Update `Dtb.DSC.psd1` metadata (Author, CompanyName, LicenseUri, ProjectUri, IconUri), choose a license (e.g., MIT), and set SemVer to `0.9.0` for the pre-1.0 stabilization.
- Ensure module loads via standard PSModulePath layout; provide an `Install-Module` path if publishing externally later.
- Add changelog (`CHANGELOG.md`) and keepers.

Acceptance criteria

- `Import-Module` works from a packaged folder.
- `Get-Module Dtb.DSC -ListAvailable` shows correct metadata.

1) Simple DSL consolidation (P1)

- Decide positioning: keep `Simple.DSC.Basic.psm1` as “examples/experimental”, and promote `Simple.DSC.psm1` as the main converter—or mark both experimental until hardened.
- Replace basic YAML parsing with a robust approach (e.g., `powershell-yaml` or built-in `ConvertFrom-Yaml` where available), or maintain a clear warning/guard.
- Provide 2–3 polished examples and e2e guide.

Acceptance criteria

- One clear documented path to use the DSL; experimental features are annotated.

1) Offline, resilience, and remoting (P1)

- Add retry/backoff to network calls; improve error messages on offline builds; document offline pre-staging.
- Harden remote execution: verify DSC presence remotely, copy artifacts safely, and report structured results.

Acceptance criteria

- Documented offline procedures; integration tests simulate missing network and pass with pre-staged archives.

1) CI/CD and releases (P1)

- Add GitHub Actions workflows (or Azure DevOps) to: lint, test, package, and create GitHub Releases with artifacts. Optionally push to PowerShell Gallery (manual step first).
- Tag `v0.9.0` then `v1.0.0` after rebranding (StateSmith) and freeze.

Acceptance criteria

- One-click release pipeline produces a signed module zip/nupkg (signing optional initially) and publishes release notes.

1) Rebranding and migration (P1, optional if name changes)

- See `REBRANDING.md` for the full plan. Execute after P0 milestones to avoid churn.

## Release criteria for 1.0.0

- Public API stable and documented with comment-based help and README examples.
- All quality gates green (lint, tests). No known critical issues in tracker.
- Packaging metadata correct; license chosen; changelog present.
- If rebranded: repo, module names, docs, and examples updated; shims/aliases provided or migration guide documented.

## Issue tracker labels (suggested)

- area:core, area:dsl, area:remoting, area:caching
- kind:bug, kind:feature, kind:docs, kind:tests, kind:build
- priority:P0/P1/P2

## Next 2–3 releases (tentative)

- 0.9.0: API alignment, tests, linting, packaging, initial CI
- 1.0.0: rebrand (if any), docs polish, remote/offline hardening
- 1.1.0: multi-platform package management (apt/yum/homebrew), more resources

